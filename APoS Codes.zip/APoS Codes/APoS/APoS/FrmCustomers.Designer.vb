﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCustomers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCustomers))
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.imList = New System.Windows.Forms.ImageList(Me.components)
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.CmdEdit = New System.Windows.Forms.Button()
        Me.CmdNew = New System.Windows.Forms.Button()
        Me.CmdDelete = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.CmdSaveChanges = New System.Windows.Forms.Button()
        Me.lvcustomers = New System.Windows.Forms.ListView()
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader14 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CmdMoveBack = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.PnlNew_Edit = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TxtCustoname = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TxtTelephone = New System.Windows.Forms.TextBox()
        Me.TxtAdd = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtCreditLimit = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TxtMobile = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.PnlNew_Edit.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(23, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 94
        Me.Label5.Text = "Search:"
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 50
        '
        'imList
        '
        Me.imList.ImageStream = CType(resources.GetObject("imList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imList.TransparentColor = System.Drawing.Color.Transparent
        Me.imList.Images.SetKeyName(0, "Cash-32.png")
        Me.imList.Images.SetKeyName(1, "Cash-321.png")
        Me.imList.Images.SetKeyName(2, "delete-32.png")
        Me.imList.Images.SetKeyName(3, "Delete(1).ico")
        Me.imList.Images.SetKeyName(4, "Delete-32(1).png")
        Me.imList.Images.SetKeyName(5, "Refresh.ico")
        Me.imList.Images.SetKeyName(6, "Add-32.png")
        Me.imList.Images.SetKeyName(7, "Printer-32.png")
        Me.imList.Images.SetKeyName(8, "receipt-32.png")
        Me.imList.Images.SetKeyName(9, "Printer-32(1).png")
        Me.imList.Images.SetKeyName(10, "Credit-32.png")
        Me.imList.Images.SetKeyName(11, "Credit-32(1).png")
        Me.imList.Images.SetKeyName(12, "Card-In-Use-32.png")
        Me.imList.Images.SetKeyName(13, "exit-32.png")
        Me.imList.Images.SetKeyName(14, "Fullscreen_Exit_Alt-Vector-32.png")
        Me.imList.Images.SetKeyName(15, "Save-32.png")
        Me.imList.Images.SetKeyName(16, "Save-32(1).png")
        Me.imList.Images.SetKeyName(17, "Return-32.png")
        Me.imList.Images.SetKeyName(18, "User_32.png")
        Me.imList.Images.SetKeyName(19, "Gnome-System-Software-Update-32.png")
        Me.imList.Images.SetKeyName(20, "Inventory-maintenance-32.png")
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(77, 14)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(343, 24)
        Me.txtSearch.TabIndex = 92
        '
        'CmdEdit
        '
        Me.CmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdEdit.ImageIndex = 15
        Me.CmdEdit.Location = New System.Drawing.Point(153, 454)
        Me.CmdEdit.Name = "CmdEdit"
        Me.CmdEdit.Size = New System.Drawing.Size(164, 30)
        Me.CmdEdit.TabIndex = 90
        Me.CmdEdit.Text = "&Edit "
        Me.CmdEdit.UseVisualStyleBackColor = True
        '
        'CmdNew
        '
        Me.CmdNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdNew.ImageIndex = 6
        Me.CmdNew.Location = New System.Drawing.Point(0, 454)
        Me.CmdNew.Name = "CmdNew"
        Me.CmdNew.Size = New System.Drawing.Size(148, 30)
        Me.CmdNew.TabIndex = 91
        Me.CmdNew.Text = "&Add New"
        Me.CmdNew.UseVisualStyleBackColor = True
        '
        'CmdDelete
        '
        Me.CmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdDelete.ImageIndex = 4
        Me.CmdDelete.Location = New System.Drawing.Point(323, 454)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(129, 30)
        Me.CmdDelete.TabIndex = 89
        Me.CmdDelete.Text = "&Delete"
        Me.CmdDelete.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.Image = Global.APoS.My.Resources.Resources.search2
        Me.btnSearch.Location = New System.Drawing.Point(423, 14)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(0)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(30, 24)
        Me.btnSearch.TabIndex = 93
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'CmdSaveChanges
        '
        Me.CmdSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdSaveChanges.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSaveChanges.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdSaveChanges.ImageIndex = 16
        Me.CmdSaveChanges.Location = New System.Drawing.Point(309, 298)
        Me.CmdSaveChanges.Name = "CmdSaveChanges"
        Me.CmdSaveChanges.Size = New System.Drawing.Size(99, 26)
        Me.CmdSaveChanges.TabIndex = 46
        Me.CmdSaveChanges.Text = "&Save changes"
        Me.CmdSaveChanges.UseVisualStyleBackColor = True
        '
        'lvcustomers
        '
        Me.lvcustomers.BackColor = System.Drawing.Color.White
        Me.lvcustomers.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader11, Me.ColumnHeader12, Me.ColumnHeader13, Me.ColumnHeader14, Me.ColumnHeader15, Me.ColumnHeader16, Me.ColumnHeader17})
        Me.lvcustomers.FullRowSelect = True
        Me.lvcustomers.GridLines = True
        Me.lvcustomers.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvcustomers.HideSelection = False
        Me.lvcustomers.Location = New System.Drawing.Point(12, 44)
        Me.lvcustomers.MultiSelect = False
        Me.lvcustomers.Name = "lvcustomers"
        Me.lvcustomers.Size = New System.Drawing.Size(940, 430)
        Me.lvcustomers.SmallImageList = Me.imList
        Me.lvcustomers.StateImageList = Me.imList
        Me.lvcustomers.TabIndex = 88
        Me.lvcustomers.UseCompatibleStateImageBehavior = False
        Me.lvcustomers.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader11
        '
        Me.ColumnHeader11.Text = "Customer Name"
        Me.ColumnHeader11.Width = 200
        '
        'ColumnHeader12
        '
        Me.ColumnHeader12.Text = "Address"
        Me.ColumnHeader12.Width = 150
        '
        'ColumnHeader13
        '
        Me.ColumnHeader13.Text = "Telephone"
        Me.ColumnHeader13.Width = 100
        '
        'ColumnHeader14
        '
        Me.ColumnHeader14.Text = "Mobile"
        Me.ColumnHeader14.Width = 100
        '
        'ColumnHeader15
        '
        Me.ColumnHeader15.Text = "Email"
        Me.ColumnHeader15.Width = 100
        '
        'ColumnHeader16
        '
        Me.ColumnHeader16.Text = "Credit Limit"
        Me.ColumnHeader16.Width = 79
        '
        'ColumnHeader17
        '
        Me.ColumnHeader17.Width = 0
        '
        'CmdMoveBack
        '
        Me.CmdMoveBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdMoveBack.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdMoveBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdMoveBack.ImageIndex = 5
        Me.CmdMoveBack.Location = New System.Drawing.Point(414, 298)
        Me.CmdMoveBack.Name = "CmdMoveBack"
        Me.CmdMoveBack.Size = New System.Drawing.Size(99, 26)
        Me.CmdMoveBack.TabIndex = 47
        Me.CmdMoveBack.Text = "&Close"
        Me.CmdMoveBack.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(52, 244)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(58, 13)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "Credit Limit"
        '
        'PnlNew_Edit
        '
        Me.PnlNew_Edit.Controls.Add(Me.CmdSaveChanges)
        Me.PnlNew_Edit.Controls.Add(Me.CmdMoveBack)
        Me.PnlNew_Edit.Controls.Add(Me.CmdEdit)
        Me.PnlNew_Edit.Controls.Add(Me.Label24)
        Me.PnlNew_Edit.Controls.Add(Me.CmdNew)
        Me.PnlNew_Edit.Controls.Add(Me.CmdDelete)
        Me.PnlNew_Edit.Controls.Add(Me.Label15)
        Me.PnlNew_Edit.Controls.Add(Me.TxtCustoname)
        Me.PnlNew_Edit.Controls.Add(Me.Label23)
        Me.PnlNew_Edit.Controls.Add(Me.TxtTelephone)
        Me.PnlNew_Edit.Controls.Add(Me.TxtAdd)
        Me.PnlNew_Edit.Controls.Add(Me.Label2)
        Me.PnlNew_Edit.Controls.Add(Me.TxtCreditLimit)
        Me.PnlNew_Edit.Controls.Add(Me.Label1)
        Me.PnlNew_Edit.Controls.Add(Me.Label14)
        Me.PnlNew_Edit.Controls.Add(Me.TxtMobile)
        Me.PnlNew_Edit.Controls.Add(Me.TxtEmail)
        Me.PnlNew_Edit.Location = New System.Drawing.Point(12, 37)
        Me.PnlNew_Edit.Name = "PnlNew_Edit"
        Me.PnlNew_Edit.Size = New System.Drawing.Size(940, 502)
        Me.PnlNew_Edit.TabIndex = 87
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(52, 28)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(82, 13)
        Me.Label24.TabIndex = 30
        Me.Label24.Text = "Customer Name"
        '
        'TxtCustoname
        '
        Me.TxtCustoname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TxtCustoname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TxtCustoname.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCustoname.Location = New System.Drawing.Point(52, 44)
        Me.TxtCustoname.Name = "TxtCustoname"
        Me.TxtCustoname.Size = New System.Drawing.Size(456, 20)
        Me.TxtCustoname.TabIndex = 27
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(52, 75)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(45, 13)
        Me.Label23.TabIndex = 32
        Me.Label23.Text = "Address"
        '
        'TxtTelephone
        '
        Me.TxtTelephone.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtTelephone.Location = New System.Drawing.Point(52, 210)
        Me.TxtTelephone.Name = "TxtTelephone"
        Me.TxtTelephone.Size = New System.Drawing.Size(213, 20)
        Me.TxtTelephone.TabIndex = 28
        '
        'TxtAdd
        '
        Me.TxtAdd.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtAdd.Location = New System.Drawing.Point(52, 91)
        Me.TxtAdd.Name = "TxtAdd"
        Me.TxtAdd.Size = New System.Drawing.Size(456, 20)
        Me.TxtAdd.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 194)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 41
        Me.Label2.Text = "Telphone"
        '
        'TxtCreditLimit
        '
        Me.TxtCreditLimit.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCreditLimit.Location = New System.Drawing.Point(52, 260)
        Me.TxtCreditLimit.Name = "TxtCreditLimit"
        Me.TxtCreditLimit.Size = New System.Drawing.Size(213, 20)
        Me.TxtCreditLimit.TabIndex = 34
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(292, 194)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Mobile"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(49, 125)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(32, 13)
        Me.Label14.TabIndex = 38
        Me.Label14.Text = "Email"
        '
        'TxtMobile
        '
        Me.TxtMobile.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtMobile.Location = New System.Drawing.Point(295, 210)
        Me.TxtMobile.Name = "TxtMobile"
        Me.TxtMobile.Size = New System.Drawing.Size(213, 20)
        Me.TxtMobile.TabIndex = 39
        '
        'TxtEmail
        '
        Me.TxtEmail.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtEmail.Location = New System.Drawing.Point(52, 141)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(456, 20)
        Me.TxtEmail.TabIndex = 35
        '
        'FrmCustomers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(959, 545)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.lvcustomers)
        Me.Controls.Add(Me.PnlNew_Edit)
        Me.Name = "FrmCustomers"
        Me.Text = "FrmCustomers"
        Me.PnlNew_Edit.ResumeLayout(False)
        Me.PnlNew_Edit.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label5 As Label
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents imList As ImageList
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents CmdEdit As Button
    Friend WithEvents CmdNew As Button
    Friend WithEvents CmdDelete As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents CmdSaveChanges As Button
    Friend WithEvents lvcustomers As ListView
    Friend WithEvents CmdMoveBack As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents PnlNew_Edit As Panel
    Friend WithEvents Label24 As Label
    Friend WithEvents TxtCustoname As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents TxtTelephone As TextBox
    Friend WithEvents TxtAdd As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtCreditLimit As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TxtMobile As TextBox
    Friend WithEvents TxtEmail As TextBox
    Friend WithEvents ColumnHeader11 As ColumnHeader
    Friend WithEvents ColumnHeader12 As ColumnHeader
    Friend WithEvents ColumnHeader13 As ColumnHeader
    Friend WithEvents ColumnHeader14 As ColumnHeader
    Friend WithEvents ColumnHeader15 As ColumnHeader
    Friend WithEvents ColumnHeader16 As ColumnHeader
    Friend WithEvents ColumnHeader17 As ColumnHeader
End Class
