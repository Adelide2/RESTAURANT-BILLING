﻿Imports MySql.Data.MySqlClient
Imports System.IO


Module ModMain
    'db connections
    Public gSqlConnection As New MySqlConnection
    Public MySqlServerPass As String = "123456789"
    Public MySqlServerHostName As String = "localhost"
    Public MySqlServerPort As String = "3306"
    Public MySqlServerUser As String = "root"
    Public MySqlDbaseName As String = "ApoSDB"
    Public gWriteSqlConnStr As Boolean = False
    Public mCancelPrintBill As Boolean = False


    Public gConnString As String = "server=" & MySqlServerHostName & ";port=" & MySqlServerPort & ";uid=" & MySqlServerUser &
     ";password=" & MySqlServerPass & ";database=" & MySqlDbaseName & ";"

    Public gWriteSuccessfull As Boolean = False

    'users
    Public gUserId As String = ""
    Public gUserName As String = ""
    Public Sub open_server()
        Application.DoEvents()
        Dim FILE_NAME As String = ""
        FILE_NAME = Application.StartupPath & "\" & "ApoS.ini"

        If gWriteSqlConnStr = True Then
            saveSqlConStr()
        End If
        'read db connection file
        If File.Exists(FILE_NAME) = True Then
            Dim MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(FILE_NAME)

            While Not MyReader.EndOfData
                Dim mStr As String = MyReader.ReadLine
                If InStr(mStr, "DbName") <> 0 Then
                    MySqlDbaseName = Replace(mStr, "DbName: ", "")
                End If

                If InStr(mStr, "DbServerName") <> 0 Then
                    MySqlServerHostName = Replace(mStr, "DbServerName: ", "")
                End If

                If InStr(mStr, "DbServerPass") <> 0 Then
                    MySqlServerPass = Replace(mStr, "DbServerPass: ", "")
                End If

                If InStr(mStr, "DbServerPort") <> 0 Then
                    MySqlServerPort = Replace(mStr, "DbServerPort: ", "")
                End If

                If InStr(mStr, "DBServerUser") <> 0 Then
                    MySqlServerUser = Replace(mStr, "DBServerUser: ", "")
                End If
            End While

            MyReader.Close()

            gConnString = "server=" & MySqlServerHostName & ";port=" & MySqlServerPort & ";uid=" & MySqlServerUser &
        ";password=" & MySqlServerPass & ";" & ";database=" & MySqlDbaseName & ";"

            gSqlConnection = New MySqlConnection(gConnString)

            Try
                gSqlConnection.Open()
            Catch ex As Exception
                frmDbSettings.ShowDialog()
            End Try
        Else
            MsgBox("Database configuration file not found")
            frmDbSettings.ShowDialog()

        End If
    End Sub

    Public Function ParseSql(sqlStr As String) As String
        sqlStr = Replace(sqlStr, "'", "''")
        sqlStr = Replace(sqlStr, "\", "\\")
        Return sqlStr
    End Function
    Public Sub saveSqlConStr()
        Dim FILE_NAME As String = "" 'Application.ExecutablePath & "\" & "ApoS.ini"
        FILE_NAME = Application.StartupPath & "\" & "ApoS.ini"
        gWriteSuccessfull = False
        Application.DoEvents()
        Try       'write dbconnection file to create a template
            If File.Exists(FILE_NAME) Then Kill(FILE_NAME)
            Dim objWriter As New System.IO.StreamWriter(FILE_NAME, True)
            objWriter.WriteLine("DbName: " & MySqlDbaseName)
            objWriter.WriteLine("DbServerName: " & MySqlServerHostName)
            objWriter.WriteLine("DbServerPass: " & MySqlServerPass)
            objWriter.WriteLine("DbServerPort: " & MySqlServerPort)
            objWriter.WriteLine("DBServerUser: " & MySqlServerUser)
            objWriter.Close()
            gWriteSuccessfull = True
        Catch ex As Exception
            MessageBox.Show("Error writing file")
            Exit Sub
        End Try
    End Sub

    Public Function SafeImageFromFile(ByVal path As String) As Image
        Using fs As New FileStream(path, FileMode.Open, FileAccess.Read)
            Dim img = Image.FromStream(fs)
            Return img
        End Using
    End Function
    Public Function SafeImageFromFile_UsingStream(ByVal path As String) As Image
        Dim bytes As Byte() = File.ReadAllBytes(path)
        Using ms As New MemoryStream(bytes)
            Dim img = Image.FromStream(ms)
            Return img
        End Using
    End Function


End Module
