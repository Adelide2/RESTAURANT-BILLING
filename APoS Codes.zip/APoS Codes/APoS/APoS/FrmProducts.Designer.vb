﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmProducts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmProducts))
        Me.TxtSellingPrice = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TxtCost = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TxtBarcode = New System.Windows.Forms.TextBox()
        Me.TxtProductType = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TxtProductname = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TxtGroup = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtLevy = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtVat = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PnlNew_Edit = New System.Windows.Forms.Panel()
        Me.CmdSaveChanges = New System.Windows.Forms.Button()
        Me.CmdMoveBack = New System.Windows.Forms.Button()
        Me.lvProducts = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.imList = New System.Windows.Forms.ImageList(Me.components)
        Me.CmdEdit = New System.Windows.Forms.Button()
        Me.CmdNew = New System.Windows.Forms.Button()
        Me.CmdDelete = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.PnlNew_Edit.SuspendLayout()
        Me.SuspendLayout()
        '
        'TxtSellingPrice
        '
        Me.TxtSellingPrice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtSellingPrice.Location = New System.Drawing.Point(295, 203)
        Me.TxtSellingPrice.Name = "TxtSellingPrice"
        Me.TxtSellingPrice.Size = New System.Drawing.Size(213, 20)
        Me.TxtSellingPrice.TabIndex = 35
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(292, 187)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(65, 13)
        Me.Label14.TabIndex = 38
        Me.Label14.Text = "Selling Price"
        '
        'TxtCost
        '
        Me.TxtCost.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtCost.Location = New System.Drawing.Point(52, 203)
        Me.TxtCost.Name = "TxtCost"
        Me.TxtCost.Size = New System.Drawing.Size(213, 20)
        Me.TxtCost.TabIndex = 34
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(52, 187)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 13)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "Cost"
        '
        'TxtBarcode
        '
        Me.TxtBarcode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtBarcode.Location = New System.Drawing.Point(52, 91)
        Me.TxtBarcode.Name = "TxtBarcode"
        Me.TxtBarcode.Size = New System.Drawing.Size(456, 20)
        Me.TxtBarcode.TabIndex = 29
        '
        'TxtProductType
        '
        Me.TxtProductType.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtProductType.Location = New System.Drawing.Point(52, 153)
        Me.TxtProductType.Name = "TxtProductType"
        Me.TxtProductType.Size = New System.Drawing.Size(213, 20)
        Me.TxtProductType.TabIndex = 28
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(52, 75)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(47, 13)
        Me.Label23.TabIndex = 32
        Me.Label23.Text = "Barcode"
        '
        'TxtProductname
        '
        Me.TxtProductname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TxtProductname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TxtProductname.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtProductname.Location = New System.Drawing.Point(52, 44)
        Me.TxtProductname.Name = "TxtProductname"
        Me.TxtProductname.Size = New System.Drawing.Size(456, 20)
        Me.TxtProductname.TabIndex = 27
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(52, 28)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(75, 13)
        Me.Label24.TabIndex = 30
        Me.Label24.Text = "Product Name"
        '
        'TxtGroup
        '
        Me.TxtGroup.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtGroup.Location = New System.Drawing.Point(295, 153)
        Me.TxtGroup.Name = "TxtGroup"
        Me.TxtGroup.Size = New System.Drawing.Size(213, 20)
        Me.TxtGroup.TabIndex = 39
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(292, 137)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Product Group"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 137)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 41
        Me.Label2.Text = "Product Type"
        '
        'TxtLevy
        '
        Me.TxtLevy.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtLevy.Location = New System.Drawing.Point(298, 262)
        Me.TxtLevy.Name = "TxtLevy"
        Me.TxtLevy.Size = New System.Drawing.Size(213, 20)
        Me.TxtLevy.TabIndex = 43
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(295, 246)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Levy Rate %"
        '
        'TxtVat
        '
        Me.TxtVat.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtVat.Location = New System.Drawing.Point(55, 262)
        Me.TxtVat.Name = "TxtVat"
        Me.TxtVat.Size = New System.Drawing.Size(213, 20)
        Me.TxtVat.TabIndex = 42
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(52, 246)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Vat Rate % "
        '
        'PnlNew_Edit
        '
        Me.PnlNew_Edit.Controls.Add(Me.CmdSaveChanges)
        Me.PnlNew_Edit.Controls.Add(Me.CmdMoveBack)
        Me.PnlNew_Edit.Controls.Add(Me.Label24)
        Me.PnlNew_Edit.Controls.Add(Me.Label15)
        Me.PnlNew_Edit.Controls.Add(Me.TxtLevy)
        Me.PnlNew_Edit.Controls.Add(Me.TxtProductname)
        Me.PnlNew_Edit.Controls.Add(Me.Label3)
        Me.PnlNew_Edit.Controls.Add(Me.Label23)
        Me.PnlNew_Edit.Controls.Add(Me.TxtVat)
        Me.PnlNew_Edit.Controls.Add(Me.TxtProductType)
        Me.PnlNew_Edit.Controls.Add(Me.Label4)
        Me.PnlNew_Edit.Controls.Add(Me.TxtBarcode)
        Me.PnlNew_Edit.Controls.Add(Me.Label2)
        Me.PnlNew_Edit.Controls.Add(Me.TxtCost)
        Me.PnlNew_Edit.Controls.Add(Me.Label1)
        Me.PnlNew_Edit.Controls.Add(Me.Label14)
        Me.PnlNew_Edit.Controls.Add(Me.TxtGroup)
        Me.PnlNew_Edit.Controls.Add(Me.TxtSellingPrice)
        Me.PnlNew_Edit.Location = New System.Drawing.Point(12, 23)
        Me.PnlNew_Edit.Name = "PnlNew_Edit"
        Me.PnlNew_Edit.Size = New System.Drawing.Size(940, 502)
        Me.PnlNew_Edit.TabIndex = 46
        '
        'CmdSaveChanges
        '
        Me.CmdSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdSaveChanges.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSaveChanges.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdSaveChanges.ImageIndex = 16
        Me.CmdSaveChanges.Location = New System.Drawing.Point(309, 298)
        Me.CmdSaveChanges.Name = "CmdSaveChanges"
        Me.CmdSaveChanges.Size = New System.Drawing.Size(99, 26)
        Me.CmdSaveChanges.TabIndex = 46
        Me.CmdSaveChanges.Text = "&Save changes"
        Me.CmdSaveChanges.UseVisualStyleBackColor = True
        '
        'CmdMoveBack
        '
        Me.CmdMoveBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdMoveBack.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdMoveBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdMoveBack.ImageIndex = 5
        Me.CmdMoveBack.Location = New System.Drawing.Point(414, 298)
        Me.CmdMoveBack.Name = "CmdMoveBack"
        Me.CmdMoveBack.Size = New System.Drawing.Size(99, 26)
        Me.CmdMoveBack.TabIndex = 47
        Me.CmdMoveBack.Text = "&Close"
        Me.CmdMoveBack.UseVisualStyleBackColor = True
        '
        'lvProducts
        '
        Me.lvProducts.BackColor = System.Drawing.Color.White
        Me.lvProducts.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8})
        Me.lvProducts.FullRowSelect = True
        Me.lvProducts.GridLines = True
        Me.lvProducts.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvProducts.HideSelection = False
        Me.lvProducts.Location = New System.Drawing.Point(12, 30)
        Me.lvProducts.MultiSelect = False
        Me.lvProducts.Name = "lvProducts"
        Me.lvProducts.Size = New System.Drawing.Size(940, 430)
        Me.lvProducts.SmallImageList = Me.imList
        Me.lvProducts.StateImageList = Me.imList
        Me.lvProducts.TabIndex = 79
        Me.lvProducts.UseCompatibleStateImageBehavior = False
        Me.lvProducts.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Product#"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Product name"
        Me.ColumnHeader2.Width = 300
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Barcode"
        Me.ColumnHeader3.Width = 150
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Cost"
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Selling Price"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Type"
        Me.ColumnHeader4.Width = 80
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Group"
        Me.ColumnHeader5.Width = 80
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Vat"
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Levy"
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "Auto_number"
        Me.ColumnHeader8.Width = 0
        '
        'imList
        '
        Me.imList.ImageStream = CType(resources.GetObject("imList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imList.TransparentColor = System.Drawing.Color.Transparent
        Me.imList.Images.SetKeyName(0, "Cash-32.png")
        Me.imList.Images.SetKeyName(1, "Cash-321.png")
        Me.imList.Images.SetKeyName(2, "delete-32.png")
        Me.imList.Images.SetKeyName(3, "Delete(1).ico")
        Me.imList.Images.SetKeyName(4, "Delete-32(1).png")
        Me.imList.Images.SetKeyName(5, "Refresh.ico")
        Me.imList.Images.SetKeyName(6, "Add-32.png")
        Me.imList.Images.SetKeyName(7, "Printer-32.png")
        Me.imList.Images.SetKeyName(8, "receipt-32.png")
        Me.imList.Images.SetKeyName(9, "Printer-32(1).png")
        Me.imList.Images.SetKeyName(10, "Credit-32.png")
        Me.imList.Images.SetKeyName(11, "Credit-32(1).png")
        Me.imList.Images.SetKeyName(12, "Card-In-Use-32.png")
        Me.imList.Images.SetKeyName(13, "exit-32.png")
        Me.imList.Images.SetKeyName(14, "Fullscreen_Exit_Alt-Vector-32.png")
        Me.imList.Images.SetKeyName(15, "Save-32.png")
        Me.imList.Images.SetKeyName(16, "Save-32(1).png")
        Me.imList.Images.SetKeyName(17, "Return-32.png")
        Me.imList.Images.SetKeyName(18, "User_32.png")
        Me.imList.Images.SetKeyName(19, "Gnome-System-Software-Update-32.png")
        Me.imList.Images.SetKeyName(20, "Inventory-maintenance-32.png")
        '
        'CmdEdit
        '
        Me.CmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdEdit.ImageIndex = 15
        Me.CmdEdit.Location = New System.Drawing.Point(165, 472)
        Me.CmdEdit.Name = "CmdEdit"
        Me.CmdEdit.Size = New System.Drawing.Size(164, 30)
        Me.CmdEdit.TabIndex = 82
        Me.CmdEdit.Text = "&Edit Product"
        Me.CmdEdit.UseVisualStyleBackColor = True
        '
        'CmdNew
        '
        Me.CmdNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdNew.ImageIndex = 6
        Me.CmdNew.Location = New System.Drawing.Point(12, 472)
        Me.CmdNew.Name = "CmdNew"
        Me.CmdNew.Size = New System.Drawing.Size(148, 30)
        Me.CmdNew.TabIndex = 83
        Me.CmdNew.Text = "&Add New Product"
        Me.CmdNew.UseVisualStyleBackColor = True
        '
        'CmdDelete
        '
        Me.CmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdDelete.ImageIndex = 4
        Me.CmdDelete.Location = New System.Drawing.Point(335, 472)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(129, 30)
        Me.CmdDelete.TabIndex = 81
        Me.CmdDelete.Text = "&Delete"
        Me.CmdDelete.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(71, 0)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(343, 24)
        Me.txtSearch.TabIndex = 84
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(23, 7)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "Search:"
        '
        'btnSearch
        '
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.Image = Global.APoS.My.Resources.Resources.search2
        Me.btnSearch.Location = New System.Drawing.Point(417, 0)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(0)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(30, 24)
        Me.btnSearch.TabIndex = 85
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'FrmProducts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(958, 514)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.CmdEdit)
        Me.Controls.Add(Me.CmdNew)
        Me.Controls.Add(Me.CmdDelete)
        Me.Controls.Add(Me.lvProducts)
        Me.Controls.Add(Me.PnlNew_Edit)
        Me.Name = "FrmProducts"
        Me.Text = "FrmProducts"
        Me.PnlNew_Edit.ResumeLayout(False)
        Me.PnlNew_Edit.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TxtSellingPrice As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents TxtCost As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TxtBarcode As TextBox
    Friend WithEvents TxtProductType As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents TxtProductname As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents TxtGroup As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtLevy As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TxtVat As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PnlNew_Edit As Panel
    Friend WithEvents lvProducts As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
    Friend WithEvents ColumnHeader7 As ColumnHeader
    Friend WithEvents ColumnHeader8 As ColumnHeader
    Friend WithEvents CmdSaveChanges As Button
    Friend WithEvents CmdMoveBack As Button
    Friend WithEvents CmdEdit As Button
    Friend WithEvents CmdNew As Button
    Friend WithEvents CmdDelete As Button
    Friend WithEvents imList As ImageList
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents ColumnHeader9 As ColumnHeader
    Friend WithEvents ColumnHeader10 As ColumnHeader
End Class
