﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmUsers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmUsers))
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CmdSaveChanges = New System.Windows.Forms.Button()
        Me.CmdMoveBack = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TxtUserID = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.TxtPassword = New System.Windows.Forms.TextBox()
        Me.TxtUserName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.imList = New System.Windows.Forms.ImageList(Me.components)
        Me.CmdEdit = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TxtConfirmPassword = New System.Windows.Forms.TextBox()
        Me.CmdNew = New System.Windows.Forms.Button()
        Me.CmdDelete = New System.Windows.Forms.Button()
        Me.PnlNew_Edit = New System.Windows.Forms.Panel()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.lvcusers = New System.Windows.Forms.ListView()
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PnlNew_Edit.SuspendLayout()
        Me.SuspendLayout()
        '
        'ColumnHeader17
        '
        Me.ColumnHeader17.Text = "Auto_Number"
        Me.ColumnHeader17.Width = 0
        '
        'ColumnHeader12
        '
        Me.ColumnHeader12.Text = "Email"
        Me.ColumnHeader12.Width = 358
        '
        'ColumnHeader11
        '
        Me.ColumnHeader11.Text = "User Name"
        Me.ColumnHeader11.Width = 379
        '
        'CmdSaveChanges
        '
        Me.CmdSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdSaveChanges.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSaveChanges.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdSaveChanges.ImageIndex = 16
        Me.CmdSaveChanges.Location = New System.Drawing.Point(309, 298)
        Me.CmdSaveChanges.Name = "CmdSaveChanges"
        Me.CmdSaveChanges.Size = New System.Drawing.Size(99, 26)
        Me.CmdSaveChanges.TabIndex = 46
        Me.CmdSaveChanges.Text = "&Save changes"
        Me.CmdSaveChanges.UseVisualStyleBackColor = True
        '
        'CmdMoveBack
        '
        Me.CmdMoveBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdMoveBack.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdMoveBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdMoveBack.ImageIndex = 5
        Me.CmdMoveBack.Location = New System.Drawing.Point(414, 298)
        Me.CmdMoveBack.Name = "CmdMoveBack"
        Me.CmdMoveBack.Size = New System.Drawing.Size(99, 26)
        Me.CmdMoveBack.TabIndex = 47
        Me.CmdMoveBack.Text = "&Close"
        Me.CmdMoveBack.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(52, 28)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(43, 13)
        Me.Label24.TabIndex = 30
        Me.Label24.Text = "User ID"
        '
        'TxtUserID
        '
        Me.TxtUserID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TxtUserID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TxtUserID.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtUserID.Location = New System.Drawing.Point(52, 44)
        Me.TxtUserID.Name = "TxtUserID"
        Me.TxtUserID.Size = New System.Drawing.Size(213, 20)
        Me.TxtUserID.TabIndex = 27
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(52, 75)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(60, 13)
        Me.Label23.TabIndex = 32
        Me.Label23.Text = "User Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(25, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 102
        Me.Label5.Text = "Search:"
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(79, 2)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(343, 24)
        Me.txtSearch.TabIndex = 100
        '
        'btnSearch
        '
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.Image = Global.APoS.My.Resources.Resources.search2
        Me.btnSearch.Location = New System.Drawing.Point(425, 2)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(0)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(30, 24)
        Me.btnSearch.TabIndex = 101
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'TxtPassword
        '
        Me.TxtPassword.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtPassword.Location = New System.Drawing.Point(52, 210)
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.Size = New System.Drawing.Size(213, 20)
        Me.TxtPassword.TabIndex = 28
        '
        'TxtUserName
        '
        Me.TxtUserName.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtUserName.Location = New System.Drawing.Point(52, 91)
        Me.TxtUserName.Name = "TxtUserName"
        Me.TxtUserName.Size = New System.Drawing.Size(456, 20)
        Me.TxtUserName.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 194)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 41
        Me.Label2.Text = "Password"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(292, 194)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 13)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Confirm Password"
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "User ID"
        Me.ColumnHeader1.Width = 142
        '
        'imList
        '
        Me.imList.ImageStream = CType(resources.GetObject("imList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imList.TransparentColor = System.Drawing.Color.Transparent
        Me.imList.Images.SetKeyName(0, "Cash-32.png")
        Me.imList.Images.SetKeyName(1, "Cash-321.png")
        Me.imList.Images.SetKeyName(2, "delete-32.png")
        Me.imList.Images.SetKeyName(3, "Delete(1).ico")
        Me.imList.Images.SetKeyName(4, "Delete-32(1).png")
        Me.imList.Images.SetKeyName(5, "Refresh.ico")
        Me.imList.Images.SetKeyName(6, "Add-32.png")
        Me.imList.Images.SetKeyName(7, "Printer-32.png")
        Me.imList.Images.SetKeyName(8, "receipt-32.png")
        Me.imList.Images.SetKeyName(9, "Printer-32(1).png")
        Me.imList.Images.SetKeyName(10, "Credit-32.png")
        Me.imList.Images.SetKeyName(11, "Credit-32(1).png")
        Me.imList.Images.SetKeyName(12, "Card-In-Use-32.png")
        Me.imList.Images.SetKeyName(13, "exit-32.png")
        Me.imList.Images.SetKeyName(14, "Fullscreen_Exit_Alt-Vector-32.png")
        Me.imList.Images.SetKeyName(15, "Save-32.png")
        Me.imList.Images.SetKeyName(16, "Save-32(1).png")
        Me.imList.Images.SetKeyName(17, "Return-32.png")
        Me.imList.Images.SetKeyName(18, "User_32.png")
        Me.imList.Images.SetKeyName(19, "Gnome-System-Software-Update-32.png")
        Me.imList.Images.SetKeyName(20, "Inventory-maintenance-32.png")
        '
        'CmdEdit
        '
        Me.CmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdEdit.ImageIndex = 15
        Me.CmdEdit.Location = New System.Drawing.Point(167, 474)
        Me.CmdEdit.Name = "CmdEdit"
        Me.CmdEdit.Size = New System.Drawing.Size(164, 30)
        Me.CmdEdit.TabIndex = 98
        Me.CmdEdit.Text = "&Edit"
        Me.CmdEdit.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(49, 125)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(32, 13)
        Me.Label14.TabIndex = 38
        Me.Label14.Text = "Email"
        '
        'TxtConfirmPassword
        '
        Me.TxtConfirmPassword.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtConfirmPassword.Location = New System.Drawing.Point(295, 210)
        Me.TxtConfirmPassword.Name = "TxtConfirmPassword"
        Me.TxtConfirmPassword.Size = New System.Drawing.Size(213, 20)
        Me.TxtConfirmPassword.TabIndex = 39
        '
        'CmdNew
        '
        Me.CmdNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdNew.ImageIndex = 6
        Me.CmdNew.Location = New System.Drawing.Point(14, 474)
        Me.CmdNew.Name = "CmdNew"
        Me.CmdNew.Size = New System.Drawing.Size(148, 30)
        Me.CmdNew.TabIndex = 99
        Me.CmdNew.Text = "&Add New"
        Me.CmdNew.UseVisualStyleBackColor = True
        '
        'CmdDelete
        '
        Me.CmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CmdDelete.ImageIndex = 4
        Me.CmdDelete.Location = New System.Drawing.Point(337, 474)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(129, 30)
        Me.CmdDelete.TabIndex = 97
        Me.CmdDelete.Text = "&Delete"
        Me.CmdDelete.UseVisualStyleBackColor = True
        '
        'PnlNew_Edit
        '
        Me.PnlNew_Edit.Controls.Add(Me.CmdSaveChanges)
        Me.PnlNew_Edit.Controls.Add(Me.CmdMoveBack)
        Me.PnlNew_Edit.Controls.Add(Me.Label24)
        Me.PnlNew_Edit.Controls.Add(Me.TxtUserID)
        Me.PnlNew_Edit.Controls.Add(Me.Label23)
        Me.PnlNew_Edit.Controls.Add(Me.TxtPassword)
        Me.PnlNew_Edit.Controls.Add(Me.TxtUserName)
        Me.PnlNew_Edit.Controls.Add(Me.Label2)
        Me.PnlNew_Edit.Controls.Add(Me.Label1)
        Me.PnlNew_Edit.Controls.Add(Me.Label14)
        Me.PnlNew_Edit.Controls.Add(Me.TxtConfirmPassword)
        Me.PnlNew_Edit.Controls.Add(Me.TxtEmail)
        Me.PnlNew_Edit.Location = New System.Drawing.Point(14, 25)
        Me.PnlNew_Edit.Name = "PnlNew_Edit"
        Me.PnlNew_Edit.Size = New System.Drawing.Size(940, 502)
        Me.PnlNew_Edit.TabIndex = 95
        '
        'TxtEmail
        '
        Me.TxtEmail.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TxtEmail.Location = New System.Drawing.Point(52, 141)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(456, 20)
        Me.TxtEmail.TabIndex = 35
        '
        'lvcusers
        '
        Me.lvcusers.BackColor = System.Drawing.Color.White
        Me.lvcusers.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader11, Me.ColumnHeader12, Me.ColumnHeader17, Me.ColumnHeader2})
        Me.lvcusers.FullRowSelect = True
        Me.lvcusers.GridLines = True
        Me.lvcusers.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvcusers.HideSelection = False
        Me.lvcusers.Location = New System.Drawing.Point(14, 32)
        Me.lvcusers.MultiSelect = False
        Me.lvcusers.Name = "lvcusers"
        Me.lvcusers.Size = New System.Drawing.Size(940, 430)
        Me.lvcusers.SmallImageList = Me.imList
        Me.lvcusers.StateImageList = Me.imList
        Me.lvcusers.TabIndex = 96
        Me.lvcusers.UseCompatibleStateImageBehavior = False
        Me.lvcusers.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "password"
        Me.ColumnHeader2.Width = 0
        '
        'FrmUsers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(969, 531)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.CmdEdit)
        Me.Controls.Add(Me.CmdNew)
        Me.Controls.Add(Me.CmdDelete)
        Me.Controls.Add(Me.lvcusers)
        Me.Controls.Add(Me.PnlNew_Edit)
        Me.Name = "FrmUsers"
        Me.Text = "FrmUsers"
        Me.PnlNew_Edit.ResumeLayout(False)
        Me.PnlNew_Edit.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ColumnHeader17 As ColumnHeader
    Friend WithEvents ColumnHeader12 As ColumnHeader
    Friend WithEvents ColumnHeader11 As ColumnHeader
    Friend WithEvents CmdSaveChanges As Button
    Friend WithEvents CmdMoveBack As Button
    Friend WithEvents Label24 As Label
    Friend WithEvents TxtUserID As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents TxtPassword As TextBox
    Friend WithEvents TxtUserName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents imList As ImageList
    Friend WithEvents CmdEdit As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents TxtConfirmPassword As TextBox
    Friend WithEvents CmdNew As Button
    Friend WithEvents CmdDelete As Button
    Friend WithEvents PnlNew_Edit As Panel
    Friend WithEvents TxtEmail As TextBox
    Friend WithEvents lvcusers As ListView
    Friend WithEvents ColumnHeader2 As ColumnHeader
End Class
