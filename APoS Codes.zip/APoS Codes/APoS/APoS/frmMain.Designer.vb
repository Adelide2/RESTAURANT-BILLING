﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TSMCompany = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSMProducts = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSMCustomers = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSMPoS = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSMUsers = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSmReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSMAdmin = New System.Windows.Forms.ToolStripMenuItem()
        Me.TSMAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSMCompany, Me.TSMProducts, Me.TSMCustomers, Me.TSMPoS, Me.TSMUsers, Me.TSmReports, Me.TSMAdmin, Me.TSMAbout})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1025, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TSMCompany
        '
        Me.TSMCompany.Name = "TSMCompany"
        Me.TSMCompany.Size = New System.Drawing.Size(71, 20)
        Me.TSMCompany.Text = "Company"
        '
        'TSMProducts
        '
        Me.TSMProducts.Name = "TSMProducts"
        Me.TSMProducts.Size = New System.Drawing.Size(66, 20)
        Me.TSMProducts.Text = "Products"
        '
        'TSMCustomers
        '
        Me.TSMCustomers.Name = "TSMCustomers"
        Me.TSMCustomers.Size = New System.Drawing.Size(76, 20)
        Me.TSMCustomers.Text = "Customers"
        '
        'TSMPoS
        '
        Me.TSMPoS.Name = "TSMPoS"
        Me.TSMPoS.Size = New System.Drawing.Size(41, 20)
        Me.TSMPoS.Text = "POS"
        '
        'TSMUsers
        '
        Me.TSMUsers.Name = "TSMUsers"
        Me.TSMUsers.Size = New System.Drawing.Size(47, 20)
        Me.TSMUsers.Text = "Users"
        '
        'TSmReports
        '
        Me.TSmReports.Name = "TSmReports"
        Me.TSmReports.Size = New System.Drawing.Size(59, 20)
        Me.TSmReports.Text = "Reports"
        '
        'TSMAdmin
        '
        Me.TSMAdmin.Name = "TSMAdmin"
        Me.TSMAdmin.Size = New System.Drawing.Size(55, 20)
        Me.TSMAdmin.Text = "Admin"
        '
        'TSMAbout
        '
        Me.TSMAbout.Name = "TSMAbout"
        Me.TSMAbout.Size = New System.Drawing.Size(52, 20)
        Me.TSMAbout.Text = "About"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(1025, 590)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "frmMain"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents TSMCompany As ToolStripMenuItem
    Friend WithEvents TSMProducts As ToolStripMenuItem
    Friend WithEvents TSMCustomers As ToolStripMenuItem
    Friend WithEvents TSMPoS As ToolStripMenuItem
    Friend WithEvents TSMUsers As ToolStripMenuItem
    Friend WithEvents TSmReports As ToolStripMenuItem
    Friend WithEvents TSMAdmin As ToolStripMenuItem
    Friend WithEvents TSMAbout As ToolStripMenuItem
End Class
