﻿Option Explicit On
Imports MySql.Data.MySqlClient


Public Class FrmUsers
    Dim UsersTbl As New DataTable
    Dim mAuto_number As Long = 0

    Private Sub load_users(Optional searchStr As String = "")
        Dim ColorMode As Integer = 0
        Try

            Dim mSqlStr As String = "select * from users "

            If searchStr <> "" Then
                mSqlStr &= "where username like '%" & searchStr & "%' or userid like '%" & searchStr & "%' "
            End If
            mSqlStr &= " order by username"

            Dim Adapter As New MySqlDataAdapter(mSqlStr, gSqlConnection)


            UsersTbl.Clear()
            Adapter.Fill(UsersTbl)
            Adapter.Dispose()

            lvcusers.Items.Clear()
            lvcusers.View = View.Details
            lvcusers.SmallImageList = imList
            Dim lvItem As ListViewItem
            Dim mtrs As String = ""

            Text = "Users  (" & UsersTbl.Rows.Count & ")"
            If UsersTbl.Rows.Count > 0 Then

                For mCount = 0 To UsersTbl.Rows.Count - 1

                    lvItem = Nothing
                    lvItem = New ListViewItem
                    lvItem.Text = UsersTbl.Rows(mCount).Item("userID").ToString
                    lvItem.SubItems.Add(UsersTbl.Rows(mCount).Item("username").ToString)
                    lvItem.SubItems.Add(UsersTbl.Rows(mCount).Item("email").ToString)
                    lvItem.SubItems.Add(UsersTbl.Rows(mCount).Item("auto_number").ToString)
                    lvItem.SubItems.Add(UsersTbl.Rows(mCount).Item("password").ToString)

                    If ColorMode = 0 Then lvItem.BackColor = Color.White
                    If ColorMode = 1 Then lvItem.BackColor = Color.MintCream
                    If ColorMode = 0 Then ColorMode = 1 Else ColorMode = 0

                    lvcusers.Items.Add(lvItem)
                    lvcusers.Items(mCount).ImageIndex = 20

                Next mCount
            End If

            Application.DoEvents()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error - " & Me.Text)
        End Try
    End Sub



    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = 13 Then btnSearch_Click(Me, New EventArgs)
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        load_users(txtSearch.Text)
    End Sub

    Private Sub CmdNew_Click(sender As Object, e As EventArgs) Handles CmdNew.Click
        mAuto_number = 0
        clearText()
        PnlNew_Edit.BringToFront()
        PnlNew_Edit.Visible = True
    End Sub

    Private Sub clearText()
        TxtUserID.Text = ""
        TxtUserName.Text = ""
        TxtPassword.Text = ""
        TxtConfirmPassword.Text = ""
        TxtEmail.Text = ""
    End Sub

    Private Sub CmdSaveChanges_Click(sender As Object, e As EventArgs) Handles CmdSaveChanges.Click
        Dim mSqlStr As String = ""

        If mAuto_number = 0 Then 'new
            'check dublicate
            Dim mTempTbl As New DataTable
            mSqlStr = "select userid,username from users where username='" & TxtUserName.Text & "' or userid='" & TxtUserID.Text & "';"
            Dim Adapter As New MySqlDataAdapter(mSqlStr, gSqlConnection)

            mTempTbl.Clear()
            Adapter.Fill(mTempTbl)
            Adapter.Dispose()

            If mTempTbl.Rows.Count <> 0 Then
                MessageBox.Show("user exists")
                Exit Sub
            End If

            mSqlStr = "Insert into users( userid,username,email,password)
                       values('" & TxtUserID.Text & "','" & TxtUserName.Text & "', '" & TxtEmail.Text & "','" & TxtPassword.Text & "');"

        Else 'edit
            mSqlStr = "update users set username='" & TxtUserName.Text & "',email='" & TxtEmail.Text & "',password='" & TxtPassword.Text & "';"
        End If


        Dim mCmd As New MySqlCommand
        mCmd.Connection = gSqlConnection
        mCmd.CommandText = mSqlStr
        Try
            mCmd.ExecuteNonQuery()
            load_users()
            PnlNew_Edit.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message & Chr(13) & "Record Not updated")
        End Try


    End Sub
    Private Sub CmdEdit_Click(sender As Object, e As EventArgs) Handles CmdEdit.Click
        If mAuto_number = 0 Then
            MessageBox.Show("Select an item to edit")
            Return
        End If

        PnlNew_Edit.BringToFront()
        PnlNew_Edit.Visible = True

    End Sub
    Private Sub DisplyRec(sItem As ListViewItem)
        TxtUserID.Text = sItem.SubItems(0).Text
        TxtUserName.Text = sItem.SubItems(1).Text
        TxtEmail.Text = sItem.SubItems(2).Text
        TxtPassword.Text = sItem.SubItems(4).Text
        TxtConfirmPassword.Text = sItem.SubItems(4).Text

    End Sub

    Private Sub lvcusers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvcusers.SelectedIndexChanged
        Try
            mAuto_number = 0

            For Each sItem As ListViewItem In lvcusers.SelectedItems
                mAuto_number = Val(sItem.SubItems(3).Text)
                DisplyRec(sItem)
                Return
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error - " & Me.Text)
        End Try
    End Sub

    Private Sub lvcusers_MouseWheel(sender As Object, e As MouseEventArgs) Handles lvcusers.MouseWheel

    End Sub

    Private Sub lvcusers_Click(sender As Object, e As EventArgs) Handles lvcusers.Click
        Try
            mAuto_number = 0

            For Each sItem As ListViewItem In lvcusers.SelectedItems
                mAuto_number = Val(sItem.SubItems(3).Text)
                DisplyRec(sItem)
                Return
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error - " & Me.Text)
        End Try
    End Sub


    Private Sub CmdDelete_Click(sender As Object, e As EventArgs) Handles CmdDelete.Click
        If mAuto_number = 0 Then
            MessageBox.Show("Select an item to edit")
            Return
        End If

        If MsgBox("Do you want to delete this record?", vbYesNo) = vbNo Then Return


        Dim mCmd As New MySqlCommand
            mCmd.Connection = gSqlConnection
        mCmd.CommandText = "Delete from users where auto_number=" & mAuto_number & ";"
        Try
            mCmd.ExecuteNonQuery()
            load_users()
        Catch ex As Exception
            MessageBox.Show(ex.Message & Chr(13) & "Record Not updated")
        End Try

    End Sub

    Private Sub CmdMoveBack_Click(sender As Object, e As EventArgs) Handles CmdMoveBack.Click
        PnlNew_Edit.Visible = False
    End Sub

    Private Sub Frmcustomers_Load(sender As Object, e As EventArgs) Handles Me.Load
        load_users()
    End Sub


End Class