﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDbSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDbSettings))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtconfirm = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmdCreate = New System.Windows.Forms.Button()
        Me.cmdSaveSett = New System.Windows.Forms.Button()
        Me.txtdatabase = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPort = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtHost = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.rtfDbScript = New System.Windows.Forms.RichTextBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(-4, -2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(422, 61)
        Me.Panel1.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(26, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(211, 24)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Mysql Server Settings"
        '
        'txtconfirm
        '
        Me.txtconfirm.Location = New System.Drawing.Point(211, 175)
        Me.txtconfirm.Name = "txtconfirm"
        Me.txtconfirm.Size = New System.Drawing.Size(185, 20)
        Me.txtconfirm.TabIndex = 33
        Me.txtconfirm.UseSystemPasswordChar = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(211, 159)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(154, 13)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "Confirm MySql server password"
        '
        'cmdCreate
        '
        Me.cmdCreate.BackColor = System.Drawing.Color.PowderBlue
        Me.cmdCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCreate.Location = New System.Drawing.Point(9, 248)
        Me.cmdCreate.Name = "cmdCreate"
        Me.cmdCreate.Size = New System.Drawing.Size(139, 39)
        Me.cmdCreate.TabIndex = 36
        Me.cmdCreate.Text = "&Create database"
        Me.cmdCreate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdCreate.UseVisualStyleBackColor = False
        '
        'cmdSaveSett
        '
        Me.cmdSaveSett.BackColor = System.Drawing.Color.PowderBlue
        Me.cmdSaveSett.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveSett.Location = New System.Drawing.Point(154, 248)
        Me.cmdSaveSett.Name = "cmdSaveSett"
        Me.cmdSaveSett.Size = New System.Drawing.Size(144, 39)
        Me.cmdSaveSett.TabIndex = 35
        Me.cmdSaveSett.Text = "&Save database settings"
        Me.cmdSaveSett.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdSaveSett.UseVisualStyleBackColor = False
        '
        'txtdatabase
        '
        Me.txtdatabase.Location = New System.Drawing.Point(9, 219)
        Me.txtdatabase.Name = "txtdatabase"
        Me.txtdatabase.Size = New System.Drawing.Size(387, 20)
        Me.txtdatabase.TabIndex = 34
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(9, 203)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(131, 13)
        Me.Label7.TabIndex = 41
        Me.Label7.Text = "Company Database Name"
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(9, 176)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(108)
        Me.txtPassword.Size = New System.Drawing.Size(186, 20)
        Me.txtPassword.TabIndex = 32
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 160)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(116, 13)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "MySql server password"
        '
        'txtUser
        '
        Me.txtUser.Location = New System.Drawing.Point(12, 132)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(183, 20)
        Me.txtUser.TabIndex = 31
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 116)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(91, 13)
        Me.Label5.TabIndex = 39
        Me.Label5.Text = "MySql server user"
        '
        'txtPort
        '
        Me.txtPort.Location = New System.Drawing.Point(211, 91)
        Me.txtPort.Name = "txtPort"
        Me.txtPort.Size = New System.Drawing.Size(185, 20)
        Me.txtPort.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(208, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "MySql server port"
        '
        'txtHost
        '
        Me.txtHost.Location = New System.Drawing.Point(12, 91)
        Me.txtHost.Name = "txtHost"
        Me.txtHost.Size = New System.Drawing.Size(183, 20)
        Me.txtHost.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "MySql server host"
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.Color.PowderBlue
        Me.cmdExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdExit.Location = New System.Drawing.Point(306, 248)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(90, 39)
        Me.cmdExit.TabIndex = 28
        Me.cmdExit.Text = "&Close"
        Me.cmdExit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'rtfDbScript
        '
        Me.rtfDbScript.Location = New System.Drawing.Point(402, 65)
        Me.rtfDbScript.Name = "rtfDbScript"
        Me.rtfDbScript.Size = New System.Drawing.Size(80, 92)
        Me.rtfDbScript.TabIndex = 43
        Me.rtfDbScript.Text = ""
        Me.rtfDbScript.Visible = False
        '
        'frmDbSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(413, 291)
        Me.Controls.Add(Me.rtfDbScript)
        Me.Controls.Add(Me.txtconfirm)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cmdCreate)
        Me.Controls.Add(Me.cmdSaveSett)
        Me.Controls.Add(Me.txtdatabase)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtUser)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPort)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtHost)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDbSettings"
        Me.Text = "frmDbSettings"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents txtconfirm As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cmdCreate As Button
    Friend WithEvents cmdSaveSett As Button
    Friend WithEvents txtdatabase As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtUser As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtPort As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtHost As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmdExit As Button
    Friend WithEvents rtfDbScript As RichTextBox
End Class
