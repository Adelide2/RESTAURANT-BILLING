﻿Option Explicit On
Imports MySql.Data.MySqlClient
Imports System.IO


Public Class frmPos
    Public mCashPaid As Double = 0
    Public mBkDepTransNo As String = ""
    Public mBillAmt As Double

    Dim CompName As String
    Dim CompAdd As String
    Dim CompTel As String
    Dim CompPin As String = ""
    Dim CompLoc As String = ""
    Dim mCompFs As Integer

    Dim ItmTbl As New DataTable
    Dim ItmGrpTbl As New DataTable
    Dim prdTbl As New DataTable
    Dim prdTbl2 As New DataTable
    Dim TaxTbl As New DataTable
    Dim CompTbl As New DataTable
    Dim SaleTbl As New DataTable
    Dim mTillName As String = ""

    Dim mTotalTaxAmt As Double = 0
    Dim mTotalAmt As Double = 0
    Dim ProductId As Long
    Dim mGrpname As String
    Dim mProductname As String = ""

    'Dim mprice As Long
    Dim mAllowQty As Integer = 1
    Dim TaxIncExc As Integer = 1
    Dim mBpPercent As Double = 70
    Dim mIfUpdateBpIf0 As Integer = 0
    Dim cTaxAmount As Double = 0
    Dim mAmount As Double = 0
    Dim mPrice As Double = 0
    Dim mDate As String = ""
    Dim mTime As String = ""
    Dim mDateDsc As String = ""
    Dim mBeginDate As String = ""


    Dim mAllowRecc As Integer = 1
    Dim TrackRdr As Integer = 1

    Dim FlagDate As Boolean = False

    Dim VatRate As Double = 0
    Dim LevyRate As Double = 0

    Dim BlockSale As Integer = 0

    Dim Ttlbprice As Double = 0
    '    Dim price As Double = 0
    Dim WsPrice As Double = 0
    Dim MinPrice As Double = 0

    Dim cItemBarcode As String = ""

    Dim cShopQty As Double = 0
    Dim cStoreQty As Double = 0
    Dim NoOfRcts As Integer = 1



    Dim rctno As Double = 0

    Dim mTable As String = "salestbl"

    Dim mRctNo As Double = 0

    Dim SaleId As Integer = 0
    Public Sub LoadItems(Grpname As String)
        Dim cntr As Integer
        Dim sqlstr As String = "select * from products  order by Productname  LIMIT 50;"
        If Grpname.Trim <> "" Then
            sqlstr = "select * from products where productgroup='" & Grpname & "' order by Productname  LIMIT 50;"
        End If

        Dim Adapter As New MySqlDataAdapter(sqlstr, gSqlConnection)
        prdTbl.Clear()
        Adapter.Fill(prdTbl)
        Adapter.Dispose()

        LstvStoreItems.Items.Clear()
        imgLstItems.Images.Clear()
        imgLstItems.ImageSize = New Size(100, 100)


        If prdTbl.Rows.Count > 0 Then
            For cntr = 0 To prdTbl.Rows.Count - 1

                'find in exe root folder in PrdImgs using item id as file name
                'Filter = "Logo Image|*.png;*.jpg;*.bmp;*.ico;*.jif|All Files|*.*"
                If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".png") = True Then
                    imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".png"))
                Else
                    If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".bmp") = True Then
                        imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".bmp"))
                    Else
                        If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".jpg") = True Then
                            imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".jpg"))
                        Else
                            If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".ico") = True Then
                                imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".ico"))
                            Else
                                imgLstItems.Images.Add(My.Resources.No_Image)
                            End If
                        End If
                    End If
                End If


                Dim lvItem As New ListViewItem(" " & prdTbl.Rows(cntr).Item("Productname").ToString, cntr)
                lvItem.SubItems.Add(prdTbl.Rows(cntr).Item("ProductId").ToString)
                lvItem.SubItems.Add(prdTbl.Rows(cntr).Item("price").ToString)
                LstvStoreItems.Items.Add(lvItem)
            Next
            LstvStoreItems.LargeImageList = imgLstItems
            ' LstvStoreItems.SmallImageList = imgLstItems
        End If
    End Sub

    Public Sub Open_Selected_Item()
        Try
            Dim mCtr As Integer
            VatRate = 0
            LevyRate = 0
            'mAllowQty = 0
            BlockSale = 0

            Ttlbprice = 0
            'mprice = 0
            WsPrice = 0
            MinPrice = 0



            If cItemBarcode = "" Then Exit Sub
            Dim Adapter As New MySqlDataAdapter("select * from products where ProductId = '" & cItemBarcode & "';", gSqlConnection)
            Dim ItemTbl As New DataTable
            ItemTbl.Clear()
            Adapter.Fill(ItemTbl)
            Adapter.Dispose()

            ProductId = ItemTbl.Rows(mCtr).Item("ProductId").ToString
            mProductname = ItemTbl.Rows(mCtr).Item("Productname").ToString
            VatRate = ItemTbl.Rows(mCtr).Item("vatrate").ToString
            LevyRate = ItemTbl.Rows(mCtr).Item("LevyRate").ToString

            Ttlbprice = Val(ItemTbl.Rows(mCtr).Item("cost").ToString)
            mPrice = Val(ItemTbl.Rows(mCtr).Item("price").ToString)
            Return

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


    Public Sub LoadItmGrp()
        lstvStoreGroups.Items.Clear()

        Dim Adapter As New MySqlDataAdapter("select distinct(Productgroup) from products order by Productgroup asc;", gSqlConnection)

        ItmGrpTbl.Clear()
        Adapter.Fill(ItmGrpTbl)
        Adapter.Dispose()
        imgLstGrps.Images.Clear()

        ' Dim lvItem As ListViewItem
        imgLstGrps.ImageSize = New Size(100, 100)

        If ItmGrpTbl.Rows.Count > 0 Then
            For cntr = 0 To ItmGrpTbl.Rows.Count - 1
                imgLstGrps.Images.Add(My.Resources.GrpIccon)
                Dim lvItem As New ListViewItem(" " & ItmGrpTbl.Rows(cntr).Item("Productgroup").ToString, cntr)
                'lvItem.SubItems.Add(ItmGrpTbl.Rows(cntr).Item("ProductId").ToString)
                lstvStoreGroups.Items.Add(lvItem)
            Next

            lstvStoreGroups.LargeImageList = imgLstGrps
            lstvStoreGroups.SmallImageList = imgLstGrps
        End If

    End Sub



    Private Sub lstvStoreGroups_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstvStoreGroups.SelectedIndexChanged
        Try
            For Each sItem As ListViewItem In lstvStoreGroups.SelectedItems
                mGrpname = sItem.Text.Trim
                LoadItems(mGrpname)
            Next


        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub

    Private Sub LstvStoreItems_Click(sender As Object, e As EventArgs) Handles LstvStoreItems.Click
        Try
            mPrice = 0
            rctno = 0
            Dim SQLcommand As New MySqlCommand
            Dim cAutoNO As Double = 0
            For Each sItem As ListViewItem In LstvStoreItems.SelectedItems
                ProductId = Val(sItem.SubItems(1).Text)
                cItemBarcode = ProductId
                mProductname = sItem.Text.Trim

                mPrice = Val(sItem.SubItems(2).Text)
                Dim mQty As Double = 1


                'get stock qty
                Open_Selected_Item()

                mAmount = mPrice * mQty
                cTaxAmount = (mAmount * VatRate) / (VatRate + 100) 'tax inclusive 
                cTaxAmount += (mAmount * LevyRate) / (LevyRate + 100) 'tax inclusive 

                If Val(mPrice) = 0 Then
                    MsgBox("Unit Price cannot be zero", MsgBoxStyle.Exclamation, "Missing Details")
                    Exit Sub
                End If



                mDate = Now.Date.ToString("yyyyMMdd")
                mDateDsc = Now.ToLongDateString

                Dim mTime As String = TimeOfDay.TimeOfDay.ToString
                Dim cDetails As String = "Incomplete Cash Sale "

                Dim NewSale As Boolean = True
                Dim Adapter As New MySqlDataAdapter
                NewSale = True

                Dim CheckTbl As New DataTable

                mQty = 1

                If SaleId <> 0 Then
                    Adapter = New MySqlDataAdapter("select price,qty,amount,auto_number from " & mTable &
                                                   " where saleid = '" & Val(SaleId) &
                                                   "' and (rctno = 0 or rctno is Null) and ProductId = '" &
                                                   ProductId & "' and Productname = '" & mProductname & "' and date = '" & mDate & "' and complete = 0 ;", gSqlConnection)
                    CheckTbl.Clear()
                    Adapter.Fill(CheckTbl)
                    Adapter.Dispose()
                    If CheckTbl.Rows.Count > 0 Then
                        'check prices
                        If mPrice = Val(CheckTbl.Rows(0).Item("price").ToString) Then
                            NewSale = False
                        End If
                        'mQty =  Val(CheckTbl.Rows(0).Item("qty").ToString)
                    End If
                Else
                    SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection
                    SQLcommand.CommandText = "select max(saleid)+1 from " & mTable & " ;"
                    Try
                        SaleId = SQLcommand.ExecuteScalar
                    Catch ex As Exception
                        SaleId = 1
                    End Try

                End If

                Dim mBuyingTtl As Double = Ttlbprice * mQty

                If NewSale = False Then
                    Dim ccSerial As String = ""
                    Dim ccPrice As Double = 0
                    Dim ccQty As Double = 0
                    Dim ccDiscount As Double = 0
                    Dim ccAmount As Double = 0
                    Dim ccAuto As Long = 0

                    If CheckTbl.Rows.Count > 0 Then
                        ccPrice = Val(CheckTbl.Rows(0).Item(0).ToString)
                        ccQty = Val(CheckTbl.Rows(0).Item(1).ToString)
                        ccDiscount = Val(CheckTbl.Rows(0).Item(2).ToString)
                        ccAmount = Val(CheckTbl.Rows(0).Item(3).ToString)
                        ccAuto = Val(CheckTbl.Rows(0).Item(4).ToString)
                    End If


                    ccPrice = Val(mPrice)
                    ccQty = Val(ccQty) + Val(mQty)
                    ccDiscount = 0
                    ccAmount = Val(ccAmount) + Val(mAmount)

                    cTaxAmount = (mAmount * VatRate) / (VatRate + 100) 'tax inclusive 
                    cTaxAmount += (mAmount * LevyRate) / (LevyRate + 100) 'tax inclusive 


                    mBuyingTtl = Ttlbprice * mQty

                    'update the record

                    SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection

                    SQLcommand.CommandText = "update " & mTable & " set Ttlbprice  = '" & mBuyingTtl & "',barcode = '" & cItemBarcode & "',qty = '" & Val(ccQty) &
                        "',price = '" & Val(ccPrice) & "',amount = " & Val(ccAmount) & "taxamt=" & cTaxAmount & " where saleid = " &
                        SaleId & " and (rctno = 0 or rctno is Null) and ProductId = '" &
                        ProductId & "' and Productname = '" & mProductname & "' and date = '" & mDate & "';"

                    SQLcommand.ExecuteNonQuery()

                Else



                    SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection
                    SQLcommand.CommandText =
                        "insert into " & mTable & " (rctno,ProductId,Productname,qty,price,Ttlbprice,amount,VatRate,LevyRate,taxamt,date,time" _
                       & ",userid,barcode,saleid,datedsc) VALUES (" & rctno & "," & Val(ProductId) & ",'" &
                       mProductname & "'," & mQty & "" _
                       & "," & Val(mPrice) & "," & Val(mBuyingTtl) & "," & Val(mAmount) & "," & VatRate & "," & LevyRate & "" _
                       & "," & cTaxAmount & ",'" & mDate & "','" & mTime & "','" & gUserId & "','" & cItemBarcode & "'," &
                       SaleId & ",'" & mDateDsc & "');"

                    SQLcommand.ExecuteNonQuery()
                End If


                grdSales.Rows.Clear()

                Open_Sale()

            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub

    Public Sub Open_Sale()
        Try
            Dim lProductId, lProductname, lItemQty, lItemPrice, lItemAmount, lItemAuto As String
            mTotalAmt = 0
            mTotalTaxAmt = 0

            mDate = Now.Date.ToString("yyyyMMdd")
            mDateDsc = Now.ToLongDateString

            Dim Adapter As New MySqlDataAdapter("select * from " & mTable & " where saleid = '" & Val(SaleId) & "' and date = '" & mDate & "' and (complete = 0 or complete is null) order by auto_number;", gSqlConnection)
            SaleTbl.Clear()
            Adapter.Fill(SaleTbl)
            Adapter.Dispose()


            If SaleTbl.Rows.Count > 0 Then
                For LoadFactor = 0 To SaleTbl.Rows.Count - 1
                    lProductId = SaleTbl.Rows(LoadFactor).Item("barcode").ToString
                    lProductname = SaleTbl.Rows(LoadFactor).Item("Productname").ToString

                    lItemQty = FormatNumber(Val(SaleTbl.Rows(LoadFactor).Item("qty").ToString), 2, TriState.True, TriState.True, TriState.True).ToString
                    lItemPrice = FormatNumber(Val(SaleTbl.Rows(LoadFactor).Item("price").ToString), 2, TriState.True, TriState.True, TriState.True).ToString

                    lItemAmount = FormatNumber(Val(SaleTbl.Rows(LoadFactor).Item("amount").ToString), 2, TriState.True, TriState.True, TriState.True).ToString
                    lItemAuto = SaleTbl.Rows(LoadFactor).Item("auto_number").ToString

                    mTotalAmt = Val(mTotalAmt) + Val(SaleTbl.Rows(LoadFactor).Item("amount").ToString)
                    mTotalTaxAmt = Val(mTotalTaxAmt) + Val(SaleTbl.Rows(LoadFactor).Item("taxamt").ToString)

                    Dim LoadStr As String() = {lItemAuto, lProductId, lProductname, lItemPrice, lItemQty, lItemAmount}

                    grdSales.Rows.Add(LoadStr)

                Next LoadFactor
                grdSales.ContextMenuStrip = ContextMenuStrip1
            Else
                grdSales.ContextMenuStrip = Nothing
            End If

            lblTotal.Text = "TOTAL: " & FormatNumber(Val(mTotalAmt), 2, TriState.True, TriState.True, TriState.True).ToString
            lblTotaltax.Text = "Tax Amount: " & FormatNumber(Val(mTotalTaxAmt), 2, TriState.True, TriState.True, TriState.True).ToString

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub

    Public Sub Delete_Incomplete_Sales()
        Try

            '''''''''''''''
            Dim Adapter As New MySqlDataAdapter '("select * from " & mTable & " where rctno=0 or rctno is null and username = '" & gUserId & "';", gSqlConnection)
            Dim SalTbl As New DataTable
            Dim SQLcommand As New MySqlCommand


            SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandText = "delete from " & mTable & " where (rctno=0 or rctno is null) and userid = '" & gUserId & "';"
            SQLcommand.ExecuteNonQuery()

        Catch ex As Exception
            '
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub



    Private Sub BtnF6_Click(sender As Object, e As EventArgs) Handles BtnF6.Click
        If grdSales.RowCount = 0 Then Return
        Dim mCash As Double = 0
        Dim SQLcommand As New MySqlCommand : SQLcommand.Connection = gSqlConnection

        mCashPaid = 0

        SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection
        Dim mTotal As Double = 0
        SQLcommand.CommandText = "select sum(amount) FROM " & mTable & " where saleid=" & SaleId & ";"
        Try
            mTotal = SQLcommand.ExecuteScalar
        Catch ex As Exception
            mTotal = 0
            MessageBox.Show(ex.Message)
            Return
        End Try


        mBillAmt = mTotal
        frmPrintReciptCurrentSale.SaleId = SaleId
        frmPrintReciptCurrentSale.mtotal = mTotal
        frmPrintReciptCurrentSale.mDate = mDate
        frmPrintReciptCurrentSale.mTime = mTime

        frmPrintReciptCurrentSale.ShowDialog()

        If mCancelPrintBill Then
            Exit Sub
        End If


        grdSales.Rows.Clear()
        Open_Sale()
        mCancelPrintBill = False
    End Sub


    Private Sub frmPosTurchScreenLv_Disposed(sender As Object, e As EventArgs) Handles Me.Disposed
        Delete_Incomplete_Sales()
    End Sub


    Private Sub grdSales_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdSales.CellContentDoubleClick
        Dim mAutoNo As Double = Val(grdSales.Rows(e.RowIndex).Cells(0).Value.ToString)

        If mAutoNo <> 0 Then
            If MsgBox("Delete " & grdSales.Rows(e.RowIndex).Cells(2).Value.ToString & " From sales list?", MessageBoxButtons.YesNo) = DialogResult.No Then Return


            Dim SQLcommand As New MySqlCommand : SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandText = "delete from " & mTable & " where auto_number=" & mAutoNo & ";"

            Try
                SQLcommand.ExecuteNonQuery()
                'If SN.IsOpen = True Then SN.Close()
                grdSales.Rows.Clear()

                Open_Sale()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub BtnF2_Click(sender As Object, e As EventArgs) Handles BtnF2.Click
        If SaleId <> 0 Then
            If MsgBox("Cancel the transaction?", MessageBoxButtons.YesNo) = DialogResult.No Then Return


            Dim SQLcommand As New MySqlCommand : SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandText = "delete from " & mTable & " where saleid=" & SaleId & ";"

            Try
                SQLcommand.ExecuteNonQuery()

                'clear
                grdSales.Rows.Clear()
                'Open_Sale_New
                SaleId = 0
                lblTotal.Text = "TOTAL: Ksh 0.00"
                lblTotaltax.Text = "Tax Amount: Ksh 0.00"

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub


    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If txtSearch.Text <> "" Then
            btnSearch_Click(Me, New EventArgs)
        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        SearchItems()
    End Sub
    Public Sub SearchItems()
        Dim cntr As Integer

        Dim Adapter As New MySqlDataAdapter("select * from PRODUCTS where Productgroup like  '%" & txtSearch.Text & "%' or Productname like  '%" & txtSearch.Text &
                                            "%' or barcode like  '%" & txtSearch.Text & "%' order by Productname  LIMIT 50;", gSqlConnection)

        prdTbl.Clear()
        Adapter.Fill(prdTbl)
        Adapter.Dispose()
        LstvStoreItems.Items.Clear()
        imgLstItems.Images.Clear()
        imgLstItems.ImageSize = New Size(100, 100)


        If prdTbl.Rows.Count > 0 Then
            For cntr = 0 To prdTbl.Rows.Count - 1

                If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".png") = True Then
                    imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".png"))
                Else
                    If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".bmp") = True Then
                        imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".bmp"))
                    Else
                        If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".jpg") = True Then
                            imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".jpg"))
                        Else
                            If File.Exists(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".ico") = True Then
                                imgLstItems.Images.Add(SafeImageFromFile(Application.StartupPath & "\PrdImgs\" & prdTbl.Rows(cntr).Item("ProductId").ToString & ".ico"))
                            Else
                                imgLstItems.Images.Add(My.Resources.No_Image)
                            End If
                        End If
                    End If
                End If

                Dim lvItem As New ListViewItem(" " & prdTbl.Rows(cntr).Item("Productname").ToString, cntr)
                lvItem.SubItems.Add(prdTbl.Rows(cntr).Item("ProductId").ToString)
                lvItem.SubItems.Add(prdTbl.Rows(cntr).Item("price").ToString)



                LstvStoreItems.Items.Add(lvItem)
            Next
            LstvStoreItems.LargeImageList = imgLstItems
            ' LstvStoreItems.SmallImageList = imgLstItems
        End If
    End Sub

    Private Sub frmPosTurchScreenLv_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        On Error Resume Next
        lstvStoreGroups.Height = Me.Height - lstvStoreGroups.Top - 50
        LstvStoreItems.Height = Me.Height - LstvStoreItems.Top - 50

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub


    Private Sub ContextMenuStrip1_Click(sender As Object, e As EventArgs) Handles ContextMenuStrip1.Click
        On Error Resume Next
        grdSales_CellContentDoubleClick(Me, New DataGridViewCellEventArgs(grdSales.CurrentCell.ColumnIndex, grdSales.CurrentCell.RowIndex))
    End Sub

    Private Sub frmPosTurchScreenLv_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        picUserImg.Image = APoS.My.Resources.Resources.Copy_of_policeman_128

        'If gUserImgName <> "" Then
        '    If File.Exists(Application.StartupPath & "\UsersPhotos\" & gUserImgName) = True Then
        '        picUserImg.Image = SafeImageFromFile_UsingStream(Application.StartupPath & "\UsersPhotos\" & gUserImgName)
        '    End If
        '    If Strings.Right(gUserImgName, 3).ToLower <> "ico" Then picUserImg.SizeMode = PictureBoxSizeMode.StretchImage
        'End If
        lblUserid.Text = gUserId
    End Sub

    Private Sub tmrFocus_Tick(sender As Object, e As EventArgs) Handles tmrFocus.Tick
        lblTimeOfDAy.Text = "TIME: " & Now.ToLongTimeString
        lblDate.Text = "DATE: " & Now.ToLongDateString
    End Sub
    Private Sub open_company()


        Dim CompTbl As New DataTable

        Dim Adapter As New MySqlDataAdapter("select * from company;", gSqlConnection)

        CompTbl.Clear()
        Adapter.Fill(CompTbl)
        Adapter.Dispose()

        If CompTbl.Rows.Count > 0 Then
            CompName = CompTbl.Rows(0).Item("compname").ToString

            CompAdd = CompTbl.Rows(0).Item("compadd").ToString
            CompTel = CompTbl.Rows(0).Item("comptel").ToString
            CompPin = CompTbl.Rows(0).Item("pinno").ToString
            CompLoc = CompTbl.Rows(0).Item("location").ToString
            NoOfRcts = 1
            mCompFs = 22


        Else
            CompName = ""
            CompAdd = ""
            CompTel = ""
        End If
    End Sub
    Private Sub frmPos_Load(sender As Object, e As EventArgs) Handles Me.Load
        mDate = Now.Date.ToString("yyyyMMdd")

        Me.KeyPreview = True
        LoadItmGrp()
        open_company()

        mBeginDate = mDate
        lblTotal.Text = "TOTAL: Ksh 0.00"
        lblTotaltax.Text = "Tax Amount: Ksh 0.00"

        lblUserid.Text = gUserId

        Delete_Incomplete_Sales()
        Open_Sale()
        mCancelPrintBill = False
        Dim usersTbl As New DataTable
    End Sub

    Private Sub LstvStoreItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LstvStoreItems.SelectedIndexChanged

    End Sub
End Class