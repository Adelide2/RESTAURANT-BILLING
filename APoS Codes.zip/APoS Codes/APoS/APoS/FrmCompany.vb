﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class frmCompany
    Dim SQLcommand As MySqlCommand
    Dim CompTable As New DataTable
    Dim mIfSave2Sttngs As Boolean = False

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    Private Sub frmCompany_Load(sender As Object, e As EventArgs) Handles Me.Load
        OpenCompany()
    End Sub

    Private Sub closeForm()
        Me.Close()
        Me.Dispose()
    End Sub
    Private Sub Disable_EnableCtrls_Input(mBool As Boolean)
        txtCompName.ReadOnly = mBool
        txtAlias.ReadOnly = mBool
        txtAdd.ReadOnly = mBool
        txtTel.ReadOnly = mBool
        txtMob.ReadOnly = mBool
        txtLocation.ReadOnly = mBool
        txtEmail.ReadOnly = mBool
        txtWebsite.ReadOnly = mBool
        txtPin.ReadOnly = mBool
        txtVat.ReadOnly = mBool
        txtNHIFNo.ReadOnly = mBool
        txtNSSFNo.ReadOnly = mBool
        txtregdno.ReadOnly = mBool

        cmdUpdate.Enabled = Not mBool
    End Sub
    Private Sub ClearTxt()
        txtCompName.Text = ""
        txtAlias.Text = ""
        txtAdd.Text = ""
        txtTel.Text = ""
        txtMob.Text = ""
        txtLocation.Text = ""
        txtEmail.Text = ""
        txtWebsite.Text = ""
        txtPin.Text = ""
        txtVat.Text = ""
        txtNHIFNo.Text = ""
        txtNSSFNo.Text = ""
        txtregdno.Text = ""
    End Sub
    Private Sub OpenCompany()
        Try
            Dim Adapter As New MySqlDataAdapter("select * from company;", gSqlConnection)
            ClearTxt()
            CompTable.Clear()
            Adapter.Fill(CompTable)
            Adapter.Dispose()

            If CompTable.Rows.Count = 0 Then Exit Sub

            txtCompName.Text = CompTable.Rows(0).Item("compname").ToString
            txtAlias.Text = CompTable.Rows(0).Item("CompAlias").ToString
            txtAdd.Text = CompTable.Rows(0).Item("compadd").ToString
            txtTel.Text = CompTable.Rows(0).Item("comptel").ToString
            txtMob.Text = CompTable.Rows(0).Item("compmobile").ToString
            txtLocation.Text = CompTable.Rows(0).Item("location").ToString
            txtEmail.Text = CompTable.Rows(0).Item("email").ToString
            txtWebsite.Text = CompTable.Rows(0).Item("website").ToString
            txtPin.Text = CompTable.Rows(0).Item("pinno").ToString
            txtVat.Text = CompTable.Rows(0).Item("vatno").ToString
            txtNHIFNo.Text = CompTable.Rows(0).Item("NHIFNo").ToString
            txtNSSFNo.Text = CompTable.Rows(0).Item("NSSFNo").ToString
            txtregdno.Text = CompTable.Rows(0).Item("regdno").ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    <CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")>
    Private Sub cmdUpdate_Click(sender As Object, e As EventArgs) Handles cmdUpdate.Click
        Try
            If txtCompName.Text = "" Then
                MessageBox.Show("Invalid Company Name")
                Exit Sub
            End If
            SQLcommand = New MySqlCommand
            SQLcommand.Connection = gSqlConnection
            Dim mysqlQueryStr As String = ""
            If CompTable.Rows.Count <> 0 Then
                mysqlQueryStr = "update company set compname='" & ParseSql(txtCompName.Text) & "',CompAlias='" & ParseSql(txtAlias.Text) & "',compadd='" & ParseSql(txtAdd.Text) &
                    "',comptel='" & ParseSql(txtTel.Text) & "',compmobile='" & ParseSql(txtMob.Text) & "',location='" & ParseSql(txtLocation.Text) & "',email='" & ParseSql(txtEmail.Text) &
                    "',website='" & ParseSql(txtWebsite.Text) & "',pinno='" & ParseSql(txtPin.Text) & "',vatno='" & ParseSql(txtVat.Text) &
                    "',CompAlias='" & ParseSql(txtAlias.Text) & "',NHIFNo='" & ParseSql(txtNHIFNo.Text) & "',NSSFNo='" & ParseSql(txtNSSFNo.Text) & "',regdno='" & ParseSql(txtregdno.Text) & "'; "
            Else
                mysqlQueryStr = "Insert into company (compname,CompAlias,compadd,comptel,compmobile,location,email,website,pinno,vatno,NHIFNo,NSSFNo,regdno) " &
                    "values('" & ParseSql(txtCompName.Text) & "','" & ParseSql(txtAlias.Text) & "','" & ParseSql(txtAdd.Text) & "','" & ParseSql(txtTel.Text) & "','" & ParseSql(txtMob.Text) & "','" & ParseSql(txtLocation.Text) & "','" & ParseSql(txtEmail.Text) &
                    "','" & ParseSql(txtWebsite.Text) & "','" & ParseSql(txtPin.Text) & "','" & ParseSql(txtVat.Text) & "'," &
                     "'" & ParseSql(txtNHIFNo.Text) & "','" & ParseSql(txtNSSFNo.Text) & "','" & ParseSql(txtregdno.Text) & "');"
            End If

            SQLcommand.CommandText = mysqlQueryStr

            SQLcommand.ExecuteNonQuery()
            SQLcommand.Dispose()


            MsgBox("Company Details Updated.", MsgBoxStyle.Information, "Confirm.")

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error..")
        End Try
    End Sub
End Class