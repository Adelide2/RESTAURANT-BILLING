﻿Imports MySql.Data.MySqlClient

Public Class frmLogin
    Dim Adapter As New MySqlDataAdapter
    Dim UserTable As DataTable

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtPass.Text = ""
        txtUserId.Text = ""
        LblVarsion.Text = "Version: " & Application.ProductVersion

        open_server()
    End Sub

    Private Sub cmdOk_Click(sender As Object, e As EventArgs) Handles cmdOk.Click
        Adapter = New MySqlDataAdapter("select * from users where userid='" & txtUserId.Text & "' and 
                        Password='" & txtPass.Text & "' order by userid;", gSqlConnection)
        UserTable = New DataTable
        UserTable.Clear()
        Adapter.Fill(UserTable)
        Adapter.Dispose()

        If UserTable.Rows.Count = 0 Then
            Adapter = New MySqlDataAdapter("select * from users order by userid;", gSqlConnection)
            UserTable = New DataTable
            UserTable.Clear()
            Adapter.Fill(UserTable)
            Adapter.Dispose()
            If UserTable.Rows.Count = 0 Then
                MsgBox("There are no users in the database, please consult your administrator.")
                End
            Else
                MsgBox("Invalid user ID or Password.")
                Exit Sub
            End If
        End If

        'password should be case senstive
        If UserTable.Rows(0).Item("userid").ToString <> txtUserId.Text Or
                UserTable.Rows(0).Item("Password").ToString <> txtPass.Text Then
            MsgBox("Invalid user ID or Password.")
            Exit Sub
        End If

        gUserId = txtUserId.Text
        gUserName = UserTable.Rows(0).Item("UserName").ToString
        frmMain.Text = "Astro PoS system - USER: " & gUserName & " (" & gUserId & ")"
        frmMain.Show()
        Hide()


    End Sub

    Private Sub frmLogin_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        Me.TopMost = True
    End Sub
    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        On Error Resume Next
        Dim ans As String = MsgBox("Do you want to close the system.", vbYesNo + vbExclamation, "Please confirm.")
        If ans = vbYes Then
            Application.Exit()
        End If
    End Sub

    Private Sub txtUserId_KeyDown(sender As Object, e As KeyEventArgs) Handles txtUserId.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtUserId.Text.Trim = "" Then
                MsgBox("User ID cannot be empty")
                Exit Sub
            Else
                txtPass.Focus()
            End If
        End If
    End Sub

    Private Sub txtPass_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPass.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtPass.Text.Trim = "" Then
                MsgBox("User Password cannot be empty")
                Exit Sub
            Else
                cmdOk_Click(Me, New EventArgs)
            End If
        End If
    End Sub
End Class