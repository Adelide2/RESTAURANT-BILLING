﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class frmDbSettings

    Dim SQLcommand As MySqlCommand
    Dim SQLreader As MySqlDataReader
    Dim CompTable As New DataTable
    Dim DtTable As New DataTable

    Private Sub frmdbsettibgs_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            Me.KeyPreview = True
            Me.TopMost = True
            txtHost.Text = MySqlServerHostName
            txtdatabase.Text = MySqlDbaseName
            txtPassword.Text = MySqlServerPass
            txtconfirm.Text = txtPassword.Text
            txtPort.Text = MySqlServerPort
            txtUser.Text = MySqlServerUser
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub
    Private Sub closeForm()
        Me.Close()
        Me.Dispose()
    End Sub


    Private Sub cmdSaveSett_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSaveSett.Click
        Try
            'Save the new settings
            MySqlServerHostName = txtHost.Text
            MySqlDbaseName = txtdatabase.Text
            MySqlServerPass = txtPassword.Text
            MySqlServerPort = txtPort.Text
            MySqlServerUser = txtUser.Text

            gWriteSqlConnStr = True
            open_server()
            If gWriteSuccessfull = True Then Dispose()

        Catch ex As Exception
            MsgBox("Your database settings are invalid. Please consult your system administrator or vendor for more help.", vbExclamation, "Invalid database settings.")
        End Try
    End Sub

    Private Sub cmdCreate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCreate.Click
        Try
            rtfDbScript.Text = My.Resources.ApoSScript.ToString
            If txtdatabase.Text = "" Then
                MsgBox("Please input the database name!", MsgBoxStyle.Exclamation, "Missing Details")
                txtdatabase.Focus()
                Exit Sub

                'the database must start with sysem abbreviations "APoS"
            ElseIf Strings.Left(txtdatabase.Text, 4).ToLower <> "APos" Then
                MessageBox.Show("Invalid Database name. Database name must start with 'HRMS'")
                txtdatabase.Focus()
                Exit Sub
            End If

            If txtHost.Text = "" Then
                MsgBox("Please Input The MySql Server Host Name!", MsgBoxStyle.Exclamation, "Missing Details")
                txtHost.Focus()
                Exit Sub
            End If

            If txtUser.Text = "" Then
                MsgBox("Please Input The MySql Server Host User!", MsgBoxStyle.Exclamation, "Missing Details")
                txtUser.Focus()
                Exit Sub
            End If

            If txtPort.Text = "" Then
                MsgBox("Please Input The MySql Server Port Number!", MsgBoxStyle.Exclamation, "Missing Details")
                txtPort.Focus()
                Exit Sub
            End If

            If txtPassword.Text = "" Then
                MsgBox("Please Input The MySql Server Host Password!", MsgBoxStyle.Exclamation, "Missing Details")
                txtPassword.Focus()
                Exit Sub
            End If

            'confirm mysql password  
            If txtPassword.Text <> txtconfirm.Text Then
                MsgBox("Please Confirm The MySql Server Host Password, The Passwords Don't Match.", MsgBoxStyle.Exclamation, "Missing Details")
                txtconfirm.Focus()
                Exit Sub
            End If


            txtHost.Text = Replace(txtHost.Text, "'", "''")
            txtHost.Text = Replace(txtHost.Text, "\", "\\")

            txtUser.Text = Replace(txtUser.Text, "'", "''")
            txtUser.Text = Replace(txtUser.Text, "\", "\\")

            txtPort.Text = Replace(txtPort.Text, "'", "''")
            txtPort.Text = Replace(txtPort.Text, "\", "\\")

            txtPassword.Text = Replace(txtPassword.Text, "'", "''")
            txtPassword.Text = Replace(txtPassword.Text, "\", "\\")


            'Test Access To the Database
            Dim TestConn As String = "server=" & txtHost.Text & ";port=" & txtPort.Text & ";uid=" & txtUser.Text & ";password=" & txtPassword.Text & ";"
            Dim SQLconnectTest As New MySqlConnection(TestConn)
            Dim Adapter As New MySqlDataAdapter
            Adapter = New MySqlDataAdapter("show databases;", SQLconnectTest)
            'save connection string
            MySqlDbaseName = txtdatabase.Text
            MySqlServerHostName = txtHost.Text
            MySqlServerPass = txtPassword.Text
            MySqlServerPort = txtPort.Text
            MySqlServerUser = txtUser.Text

            saveSqlConStr()


            DtTable.Clear()
            Adapter.Fill(DtTable)
            Adapter.Dispose()

            'If the test works okay then check if the database exist
            Dim CountDb As Integer = 0
            If DtTable.Rows.Count > 0 Then
                For CountDb = 0 To DtTable.Rows.Count - 1
                    If Trim(LCase(DtTable.Rows(CountDb).Item(0).ToString)) = Trim(LCase(txtdatabase.Text)) Then
                        MsgBox("The database you are trying to create already exists on the specified MySql Server." & vbCrLf & "You cant create two databases with the same name in the same database server.", MsgBoxStyle.Exclamation, "Duplication")
                        Exit Sub
                    End If
                    Application.DoEvents()
                Next CountDb
            End If

            'Create the database tables  
            SQLconnectTest.Open()
            'Create_database(SQLconnectTest)
            Create_database(TestConn, txtdatabase.Text)
            'Update info
            TestConn = TestConn & "database=" & txtdatabase.Text & ";"
            gConnString = TestConn

            SQLconnectTest.Dispose()

            open_server()

            'update default company name
            SQLcommand = New MySqlCommand
            SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandText = "INSERT INTO `company` (`Auto_Number`, `compname`, `CompAlias`, `compadd`, `comptel`, `compmobile`, `location`, `email`, `website`, `pinno`, `vatno`, `smsno`, `Password`, `NHIFNo`, `NSSFNo`, `regdno`, `SysBkgrdImgFileName`) VALUES
  (1, 'Arrosto restaurant', '', 'P.O. Box 010-102', '020 90900', '0791 900060', 'Nairobi', 'rexsofint@gmail.com', 'www.rexsof.co.ke', '', 'V5555555555', '', '', '', '', '', '');"
            SQLcommand.ExecuteNonQuery()
            SQLcommand.Dispose()

            'update defaul user name
            SQLcommand = New MySqlCommand
            SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandText = "INSERT INTO `users` (`auto_number`, `userid`,  `Userdsc`,  `Password`, `Active`) VALUES
                                                            (1, 'Admin','System Default Administrator', '123', 1);"
            SQLcommand.ExecuteNonQuery()
            SQLcommand.Dispose()


            MessageBox.Show("Database: " & txtdatabase.Text & " was Created successfully." & Chr(13) & Chr(13) _
                & "Default Administrators user name and Password is 'Admin 123456'")

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")

        End Try
    End Sub
    Private Sub Create_Database(ByVal Conn As String, DbNme As String)
        Try
            Dim gSqlConnection As New MySqlConnection(Conn)
            Dim SQLcommand As New MySqlCommand
            gSqlConnection.Open()
            'here create a database
            'every compile should be having a script(ApoSScript.txt) file embeded for creating the database
            'the script file should be a full database script including table definations

            Dim str1 As String = "CREATE DATABASE `APoSDb`
                                    CHARACTER SET 'latin1'
                                    COLLATE 'latin1_swedish_ci'; 
                                    USE `APoSDb`;   
                                    "

            str1 = Replace(str1, "APoSDb", DbNme)
            SQLcommand.CommandText = str1 & rtfDbScript.Text
            SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandTimeout = 0
            SQLcommand.ExecuteNonQuery()

            'MsgBox("Database: " & DbNme & " was created successfully")
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Dispose()
    End Sub
End Class