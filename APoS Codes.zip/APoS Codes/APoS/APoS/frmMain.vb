﻿Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        'FrmLogin.Dispose()
    End Sub


    Private Sub TSMProducts_Click(sender As Object, e As EventArgs) Handles TSMProducts.Click
        Dim NewMDIChild As New FrmProducts
        NewMDIChild.StartPosition = FormStartPosition.CenterScreen
        NewMDIChild.MdiParent = Me
        NewMDIChild.Show()
    End Sub

    Private Sub frmMain_Disposed(sender As Object, e As EventArgs) Handles Me.Disposed
        End
    End Sub

    Private Sub TSMCustomers_Click(sender As Object, e As EventArgs) Handles TSMCustomers.Click
        Dim NewMDIChild As New FrmCustomers
        NewMDIChild.StartPosition = FormStartPosition.CenterScreen
        NewMDIChild.MdiParent = Me
        NewMDIChild.Show()
    End Sub

    Private Sub TSMUsers_Click(sender As Object, e As EventArgs) Handles TSMUsers.Click
        Dim NewMDIChild As New FrmUsers
        NewMDIChild.StartPosition = FormStartPosition.CenterScreen
        NewMDIChild.MdiParent = Me
        NewMDIChild.Show()
    End Sub

    Private Sub TSMAbout_Click(sender As Object, e As EventArgs) Handles TSMAbout.Click
        Dim NewMDIChild As New AboutBox1
        NewMDIChild.StartPosition = FormStartPosition.CenterScreen
        NewMDIChild.MdiParent = Me
        NewMDIChild.Show()
    End Sub

    Private Sub TSMCompany_Click(sender As Object, e As EventArgs) Handles TSMCompany.Click
        Dim NewMDIChild As New frmCompany
        NewMDIChild.StartPosition = FormStartPosition.CenterScreen
        NewMDIChild.MdiParent = Me
        NewMDIChild.Show()
    End Sub

    Private Sub TSMPoS_Click(sender As Object, e As EventArgs) Handles TSMPoS.Click
        Dim NewMDIChild As New frmPos
        NewMDIChild.StartPosition = FormStartPosition.CenterScreen
        NewMDIChild.MdiParent = Me
        NewMDIChild.Show()
    End Sub
End Class