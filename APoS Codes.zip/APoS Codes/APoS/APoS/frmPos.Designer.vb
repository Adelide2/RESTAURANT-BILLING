﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ListViewGroup1 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
        Dim ListViewItem2 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim ListViewGroup2 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewItem3 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
        Dim ListViewItem4 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPos))
        Me.imgLstGrps = New System.Windows.Forms.ImageList(Me.components)
        Me.imgLstItems = New System.Windows.Forms.ImageList(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.DeleteSelectdToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tmrFocus = New System.Windows.Forms.Timer(Me.components)
        Me.lblTimeOfDAy = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnF6 = New System.Windows.Forms.Button()
        Me.BtnF2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.picUserImg = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.lblBillNo = New System.Windows.Forms.Label()
        Me.lblTotaltax = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.LstvStoreItems = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblCompanyName = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.grdSales = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.lstvStoreGroups = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lblDate = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.PnlPosFunctions = New System.Windows.Forms.Panel()
        Me.PnlTotals = New System.Windows.Forms.Panel()
        Me.lblUserid = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.picUserImg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdSales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.PnlPosFunctions.SuspendLayout()
        Me.PnlTotals.SuspendLayout()
        Me.SuspendLayout()
        '
        'imgLstGrps
        '
        Me.imgLstGrps.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgLstGrps.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgLstGrps.TransparentColor = System.Drawing.Color.Transparent
        '
        'imgLstItems
        '
        Me.imgLstItems.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgLstItems.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgLstItems.TransparentColor = System.Drawing.Color.Transparent
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteSelectdToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(149, 26)
        '
        'DeleteSelectdToolStripMenuItem
        '
        Me.DeleteSelectdToolStripMenuItem.Name = "DeleteSelectdToolStripMenuItem"
        Me.DeleteSelectdToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.DeleteSelectdToolStripMenuItem.Text = "Delete Selectd"
        '
        'tmrFocus
        '
        Me.tmrFocus.Enabled = True
        Me.tmrFocus.Interval = 300
        '
        'lblTimeOfDAy
        '
        Me.lblTimeOfDAy.Font = New System.Drawing.Font("Georgia", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeOfDAy.ForeColor = System.Drawing.Color.Black
        Me.lblTimeOfDAy.Location = New System.Drawing.Point(767, 27)
        Me.lblTimeOfDAy.Name = "lblTimeOfDAy"
        Me.lblTimeOfDAy.Size = New System.Drawing.Size(292, 20)
        Me.lblTimeOfDAy.TabIndex = 118
        Me.lblTimeOfDAy.Text = "Time Of Day: hh:mm:ss"
        Me.lblTimeOfDAy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Location = New System.Drawing.Point(748, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(13, 108)
        Me.Panel1.TabIndex = 116
        '
        'BtnF6
        '
        Me.BtnF6.BackColor = System.Drawing.Color.PowderBlue
        Me.BtnF6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnF6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnF6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnF6.Location = New System.Drawing.Point(3, 63)
        Me.BtnF6.Name = "BtnF6"
        Me.BtnF6.Size = New System.Drawing.Size(124, 46)
        Me.BtnF6.TabIndex = 211
        Me.BtnF6.TabStop = False
        Me.BtnF6.Text = " Print Re&ceipt"
        Me.BtnF6.UseVisualStyleBackColor = False
        '
        'BtnF2
        '
        Me.BtnF2.BackColor = System.Drawing.Color.PowderBlue
        Me.BtnF2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnF2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnF2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnF2.Location = New System.Drawing.Point(5, 9)
        Me.BtnF2.Name = "BtnF2"
        Me.BtnF2.Size = New System.Drawing.Size(124, 46)
        Me.BtnF2.TabIndex = 210
        Me.BtnF2.TabStop = False
        Me.BtnF2.Text = "Cancel Sale"
        Me.BtnF2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.PowderBlue
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(2, 527)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(127, 94)
        Me.Button1.TabIndex = 204
        Me.Button1.TabStop = False
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'picUserImg
        '
        Me.picUserImg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picUserImg.Image = Global.APoS.My.Resources.Resources.Customer_Male_Light_64__Custom___2_
        Me.picUserImg.Location = New System.Drawing.Point(1063, 2)
        Me.picUserImg.Name = "picUserImg"
        Me.picUserImg.Size = New System.Drawing.Size(130, 106)
        Me.picUserImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picUserImg.TabIndex = 117
        Me.picUserImg.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.APoS.My.Resources.Resources.at_icon
        Me.PictureBox9.Location = New System.Drawing.Point(1199, -1)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(130, 106)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 115
        Me.PictureBox9.TabStop = False
        '
        'lblBillNo
        '
        Me.lblBillNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBillNo.Location = New System.Drawing.Point(767, 76)
        Me.lblBillNo.Name = "lblBillNo"
        Me.lblBillNo.Size = New System.Drawing.Size(290, 32)
        Me.lblBillNo.TabIndex = 3
        Me.lblBillNo.Text = "Bill No. ---"
        Me.lblBillNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotaltax
        '
        Me.lblTotaltax.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotaltax.Location = New System.Drawing.Point(3, 81)
        Me.lblTotaltax.Name = "lblTotaltax"
        Me.lblTotaltax.Size = New System.Drawing.Size(740, 25)
        Me.lblTotaltax.TabIndex = 1
        Me.lblTotaltax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotal
        '
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(-1, 37)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(744, 41)
        Me.lblTotal.TabIndex = 0
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'ImageList2
        '
        Me.ImageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList2.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        '
        'LstvStoreItems
        '
        Me.LstvStoreItems.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4})
        ListViewGroup1.Header = "ListViewGroup"
        ListViewGroup1.Name = "ListViewGroup1"
        Me.LstvStoreItems.Groups.AddRange(New System.Windows.Forms.ListViewGroup() {ListViewGroup1})
        Me.LstvStoreItems.HideSelection = False
        Me.LstvStoreItems.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1, ListViewItem2})
        Me.LstvStoreItems.Location = New System.Drawing.Point(693, 151)
        Me.LstvStoreItems.Name = "LstvStoreItems"
        Me.LstvStoreItems.Size = New System.Drawing.Size(629, 541)
        Me.LstvStoreItems.TabIndex = 225
        Me.LstvStoreItems.UseCompatibleStateImageBehavior = False
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(804, 116)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(479, 29)
        Me.txtSearch.TabIndex = 227
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(721, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 20)
        Me.Label2.TabIndex = 226
        Me.Label2.Text = "Search:"
        '
        'lblCompanyName
        '
        Me.lblCompanyName.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCompanyName.ForeColor = System.Drawing.Color.DarkMagenta
        Me.lblCompanyName.Location = New System.Drawing.Point(-1, 0)
        Me.lblCompanyName.Name = "lblCompanyName"
        Me.lblCompanyName.Size = New System.Drawing.Size(744, 32)
        Me.lblCompanyName.TabIndex = 2
        Me.lblCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblCompanyName.UseMnemonic = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 300
        '
        'grdSales
        '
        Me.grdSales.AllowUserToAddRows = False
        Me.grdSales.AllowUserToDeleteRows = False
        Me.grdSales.BackgroundColor = System.Drawing.Color.PowderBlue
        Me.grdSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdSales.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column5, Me.Column4, Me.Column6})
        Me.grdSales.ContextMenuStrip = Me.ContextMenuStrip2
        Me.grdSales.Location = New System.Drawing.Point(122, 109)
        Me.grdSales.Name = "grdSales"
        Me.grdSales.RowTemplate.Height = 28
        Me.grdSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdSales.Size = New System.Drawing.Size(565, 293)
        Me.grdSales.TabIndex = 222
        '
        'Column1
        '
        Me.Column1.HeaderText = "AutoNo"
        Me.Column1.Name = "Column1"
        Me.Column1.Visible = False
        '
        'Column2
        '
        Me.Column2.HeaderText = "ItemId"
        Me.Column2.Name = "Column2"
        Me.Column2.Visible = False
        '
        'Column3
        '
        Me.Column3.HeaderText = "item Name"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 200
        '
        'Column5
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column5.DefaultCellStyle = DataGridViewCellStyle1
        Me.Column5.HeaderText = "Price"
        Me.Column5.Name = "Column5"
        '
        'Column4
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column4.DefaultCellStyle = DataGridViewCellStyle2
        Me.Column4.HeaderText = "Quatity"
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 80
        '
        'Column6
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column6.HeaderText = "Amount"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 140
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(149, 26)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem1.Text = "Delete Selectd"
        '
        'lstvStoreGroups
        '
        Me.lstvStoreGroups.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        ListViewGroup2.Header = "ListViewGroup"
        ListViewGroup2.Name = "ListViewGroup1"
        Me.lstvStoreGroups.Groups.AddRange(New System.Windows.Forms.ListViewGroup() {ListViewGroup2})
        Me.lstvStoreGroups.HideSelection = False
        Me.lstvStoreGroups.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem3, ListViewItem4})
        Me.lstvStoreGroups.Location = New System.Drawing.Point(122, 400)
        Me.lstvStoreGroups.Name = "lstvStoreGroups"
        Me.lstvStoreGroups.Size = New System.Drawing.Size(565, 263)
        Me.lstvStoreGroups.TabIndex = 221
        Me.lstvStoreGroups.UseCompatibleStateImageBehavior = False
        '
        'lblDate
        '
        Me.lblDate.Font = New System.Drawing.Font("Georgia", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.Black
        Me.lblDate.Location = New System.Drawing.Point(767, 3)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(292, 20)
        Me.lblDate.TabIndex = 119
        Me.lblDate.Text = "Time Of Day: hh:mm:ss"
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch
        '
        Me.btnSearch.BackColor = System.Drawing.Color.PowderBlue
        Me.btnSearch.Location = New System.Drawing.Point(1289, 113)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(36, 39)
        Me.btnSearch.TabIndex = 228
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'PnlPosFunctions
        '
        Me.PnlPosFunctions.BackColor = System.Drawing.Color.PowderBlue
        Me.PnlPosFunctions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlPosFunctions.Controls.Add(Me.BtnF6)
        Me.PnlPosFunctions.Controls.Add(Me.BtnF2)
        Me.PnlPosFunctions.Controls.Add(Me.Button1)
        Me.PnlPosFunctions.Dock = System.Windows.Forms.DockStyle.Left
        Me.PnlPosFunctions.Location = New System.Drawing.Point(0, 110)
        Me.PnlPosFunctions.Name = "PnlPosFunctions"
        Me.PnlPosFunctions.Size = New System.Drawing.Size(132, 606)
        Me.PnlPosFunctions.TabIndex = 223
        '
        'PnlTotals
        '
        Me.PnlTotals.BackColor = System.Drawing.Color.PowderBlue
        Me.PnlTotals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PnlTotals.Controls.Add(Me.lblUserid)
        Me.PnlTotals.Controls.Add(Me.lblDate)
        Me.PnlTotals.Controls.Add(Me.lblTimeOfDAy)
        Me.PnlTotals.Controls.Add(Me.picUserImg)
        Me.PnlTotals.Controls.Add(Me.Panel1)
        Me.PnlTotals.Controls.Add(Me.PictureBox9)
        Me.PnlTotals.Controls.Add(Me.lblBillNo)
        Me.PnlTotals.Controls.Add(Me.lblCompanyName)
        Me.PnlTotals.Controls.Add(Me.lblTotaltax)
        Me.PnlTotals.Controls.Add(Me.lblTotal)
        Me.PnlTotals.Dock = System.Windows.Forms.DockStyle.Top
        Me.PnlTotals.Location = New System.Drawing.Point(0, 0)
        Me.PnlTotals.Name = "PnlTotals"
        Me.PnlTotals.Size = New System.Drawing.Size(1284, 110)
        Me.PnlTotals.TabIndex = 224
        '
        'lblUserid
        '
        Me.lblUserid.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserid.Location = New System.Drawing.Point(1069, 93)
        Me.lblUserid.Margin = New System.Windows.Forms.Padding(0)
        Me.lblUserid.Name = "lblUserid"
        Me.lblUserid.Size = New System.Drawing.Size(123, 12)
        Me.lblUserid.TabIndex = 120
        Me.lblUserid.Text = "User ID:"
        Me.lblUserid.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmPos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(1284, 716)
        Me.Controls.Add(Me.LstvStoreItems)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.grdSales)
        Me.Controls.Add(Me.lstvStoreGroups)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.PnlPosFunctions)
        Me.Controls.Add(Me.PnlTotals)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmPos"
        Me.Text = "frmPos"
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.picUserImg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdSales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.PnlPosFunctions.ResumeLayout(False)
        Me.PnlTotals.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents imgLstGrps As ImageList
    Friend WithEvents imgLstItems As ImageList
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents DeleteSelectdToolStripMenuItem As ToolStripMenuItem
    Public WithEvents tmrFocus As Timer
    Friend WithEvents lblTimeOfDAy As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnF6 As Button
    Friend WithEvents BtnF2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents picUserImg As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents lblBillNo As Label
    Friend WithEvents lblTotaltax As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents ImageList2 As ImageList
    Friend WithEvents LstvStoreItems As ListView
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lblCompanyName As Label
    Public WithEvents Timer1 As Timer
    Friend WithEvents grdSales As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents ContextMenuStrip2 As ContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents lstvStoreGroups As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents lblDate As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents PnlPosFunctions As Panel
    Friend WithEvents PnlTotals As Panel
    Friend WithEvents lblUserid As Label
End Class
