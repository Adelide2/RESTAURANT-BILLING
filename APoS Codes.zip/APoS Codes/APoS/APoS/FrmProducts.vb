﻿Option Explicit On
Imports MySql.Data.MySqlClient

Public Class FrmProducts
    Dim ProductsTbl As New DataTable
    Dim mAuto_number As Long = 0

    Private Sub load_Products(Optional searchStr As String = "")
        Dim ColorMode As Integer = 0
        Try

            Dim mSqlStr As String = "select * from products "

            If searchStr <> "" Then
                mSqlStr &= "where productname like '%" & searchStr & "%' "
            End If
            mSqlStr &= " order by Productname"

            Dim Adapter As New MySqlDataAdapter(mSqlStr, gSqlConnection)


            ProductsTbl.Clear()
            Adapter.Fill(ProductsTbl)
            Adapter.Dispose()

            lvProducts.Items.Clear()
            lvProducts.View = View.Details
            lvProducts.SmallImageList = imList
            Dim lvItem As ListViewItem
            Dim mtrs As String = ""

            Text = "Products  (" & ProductsTbl.Rows.Count & ")"
            If ProductsTbl.Rows.Count > 0 Then

                For mCount = 0 To ProductsTbl.Rows.Count - 1

                    lvItem = Nothing
                    lvItem = New ListViewItem
                    lvItem.Text = ProductsTbl.Rows(mCount).Item("productid").ToString
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("productname").ToString)
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("barcode").ToString)

                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("Cost").ToString)
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("price").ToString)

                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("producttype").ToString)
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("productgroup").ToString)
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("vatRate").ToString)
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("LevyRate").ToString)
                    lvItem.SubItems.Add(ProductsTbl.Rows(mCount).Item("auto_number").ToString)

                    If ColorMode = 0 Then lvItem.BackColor = Color.White
                    If ColorMode = 1 Then lvItem.BackColor = Color.MintCream
                    If ColorMode = 0 Then ColorMode = 1 Else ColorMode = 0

                    lvProducts.Items.Add(lvItem)
                    lvProducts.Items(mCount).ImageIndex = 20

                Next mCount
            End If

            Application.DoEvents()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error - " & Me.Text)
        End Try
    End Sub


    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = 13 Then btnSearch_Click(Me, New EventArgs)
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        load_Products(txtSearch.Text)
    End Sub

    Private Sub CmdNew_Click(sender As Object, e As EventArgs) Handles CmdNew.Click
        mAuto_number = 0
        clearText()
        PnlNew_Edit.BringToFront()
        PnlNew_Edit.Visible = True

    End Sub

    Private Sub clearText()
        TxtProductname.Text = ""
        TxtBarcode.Text = ""
        TxtGroup.Text = ""
        TxtProductType.Text = ""
        TxtVat.Text = ""
        TxtLevy.Text = ""
        TxtCost.Text = ""
        TxtSellingPrice.Text = ""

    End Sub

    Private Sub CmdSaveChanges_Click(sender As Object, e As EventArgs) Handles CmdSaveChanges.Click
        Dim mSqlStr As String = ""

        If mAuto_number = 0 Then 'new
            'check dublicate
            Dim mTempTbl As New DataTable
            mSqlStr = "select productid,productname from products where productname='" & TxtProductname.Text & "';"
            Dim Adapter As New MySqlDataAdapter(mSqlStr, gSqlConnection)

            mTempTbl.Clear()
            Adapter.Fill(mTempTbl)
            Adapter.Dispose()

            If mTempTbl.Rows.Count <> 0 Then
                MessageBox.Show("Product exists")
                Exit Sub
            End If

            'get next product id
            mSqlStr = "select max(productid) from products;"
            mTempTbl.Clear()
            Adapter = New MySqlDataAdapter(mSqlStr, gSqlConnection)
            Adapter.Fill(mTempTbl)
            Adapter.Dispose()

            Dim mPrdId As Long = Val(mTempTbl.Rows(0).Item(2).ToString) + 1
            If mPrdId = 0 Then mPrdId = 1

            mSqlStr = "Insert into products( ProductId,Productname,barcode,Cost,price,Producttype,Productgroup,VatRate,LevyRate)
                       values(" & mPrdId & ",'" & TxtProductname.Text & "', '" & TxtBarcode.Text & "'," & Val(TxtCost.Text) &
                                "," & Val(TxtSellingPrice.Text) & ",'" & TxtProductType.Text & "','" & TxtGroup.Text & "'," &
                                Val(TxtVat.Text) & "," & Val(TxtLevy.Text) & ");"

        Else 'edit
            mSqlStr = "update products set Productname='" & TxtProductname.Text & "',barcode='" & TxtBarcode.Text & "',Cost=" & Val(TxtCost.Text) &
                ",price=" & Val(TxtSellingPrice.Text) & ",Producttype='" & TxtProductType.Text & "',Productgroup'" & TxtGroup.Text &
                "',VatRate=" & Val(TxtVat.Text) & ",LevyRate=" & Val(TxtLevy.Text) & ";"
        End If


        Dim mCmd As New MySqlCommand
        mCmd.Connection = gSqlConnection
        mCmd.CommandText = mSqlStr
        Try
            mCmd.ExecuteNonQuery()
            load_Products()
            PnlNew_Edit.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message & Chr(13) & "Record Not updated")
        End Try


    End Sub

    Private Sub CmdEdit_Click(sender As Object, e As EventArgs) Handles CmdEdit.Click
        If mAuto_number = 0 Then
            MessageBox.Show("Select an item to edit")
            Return
        End If

        PnlNew_Edit.BringToFront()
        PnlNew_Edit.Visible = True

    End Sub
    Private Sub DisplyRec(sItem As ListViewItem)
        TxtProductname.Text = sItem.SubItems(0).Text
        TxtBarcode.Text = sItem.SubItems(1).Text
        TxtGroup.Text = sItem.SubItems(2).Text
        TxtProductType.Text = sItem.SubItems(3).Text
        TxtVat.Text = sItem.SubItems(4).Text
        TxtLevy.Text = sItem.SubItems(5).Text
        TxtCost.Text = sItem.SubItems(6).Text
        TxtSellingPrice.Text = sItem.SubItems(7).Text

    End Sub
    Private Sub lvProducts_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvProducts.SelectedIndexChanged
        Try
            mAuto_number = 0

            For Each sItem As ListViewItem In lvProducts.SelectedItems
                mAuto_number = Val(sItem.SubItems(9).Text)
                DisplyRec(sItem)
                Return
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error - " & Me.Text)
        End Try
    End Sub

    Private Sub lvProducts_Click(sender As Object, e As EventArgs) Handles lvProducts.Click
        Try
            mAuto_number = 0

            For Each sItem As ListViewItem In lvProducts.SelectedItems
                mAuto_number = Val(sItem.SubItems(9).Text)
                DisplyRec(sItem)
                Return
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "Error - " & Me.Text)
        End Try
    End Sub

    Private Sub CmdDelete_Click(sender As Object, e As EventArgs) Handles CmdDelete.Click
        If mAuto_number = 0 Then
            MessageBox.Show("Select an item to edit")
            Return
        End If
        If MsgBox("Do you want to delete this record?", vbYesNo) = vbNo Then Return

        Dim mCmd As New MySqlCommand
        mCmd.Connection = gSqlConnection
        mCmd.CommandText = "Delete from products where auto_number=" & mAuto_number & ";"
        Try
            mCmd.ExecuteNonQuery()
            load_Products()
        Catch ex As Exception
            MessageBox.Show(ex.Message & Chr(13) & "Record Not updated")
        End Try

    End Sub

    Private Sub CmdMoveBack_Click(sender As Object, e As EventArgs) Handles CmdMoveBack.Click
        PnlNew_Edit.Visible = False
    End Sub

    Private Sub FrmProducts_Load(sender As Object, e As EventArgs) Handles Me.Load
        load_Products()
    End Sub
End Class