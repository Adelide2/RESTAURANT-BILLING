﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class frmPrintReciptCurrentSale
    Public mtotal As Double
    Public SaleId As Double
    Public mDate As String
    Public mTime As String

    Dim mTable As String = "salestbl"

    Dim mCashPaid As Double = 0
    Dim mChange As Double = 0
    Dim mRctNo As Integer = 0

    Private Sub txtcashPaid_TextChanged(sender As Object, e As EventArgs) Handles txtcashPaid.TextChanged
        mCashPaid = Val(Replace(txtcashPaid.Text, ",", ""))
        mChange = Val(mCashPaid) - Val(Replace(txtTotal.Text, ",", ""))

        TxtChange.Text = FormatNumber(Val(mChange), 2, TriState.True, TriState.True, TriState.True)
    End Sub

    Private Sub txtcashPaid_GotFocus(sender As Object, e As EventArgs) Handles txtcashPaid.GotFocus
        txtcashPaid.SelectAll()
    End Sub

    Private Sub OK_Button_Click(sender As Object, e As EventArgs) Handles OK_Button.Click
        Call frmPrintReciptCurrentSale_KeyDown(OK_Button, New KeyEventArgs(13))
    End Sub

    Private Sub frmPrintReciptCurrentSale_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Dim SumTbl As New DataTable
        Dim Adapter As New MySqlDataAdapter
        Dim SQLcommand As New MySqlCommand : SQLcommand.Connection = gSqlConnection

        If e.KeyCode = Keys.Escape Then
            mCancelPrintBill = True
            Me.Close()
            Me.Dispose()
        End If

        If e.KeyCode = Keys.Return Then

            If Val(mCashPaid) < Val(mtotal) Then
                MsgBox("Please Input More Cash To Complete The transaction.", MsgBoxStyle.Exclamation, "Cannot Continue!")
                txtcashPaid.Focus()
                Exit Sub
            End If

            ' -----------------------------------------------------------------
            SQLcommand.CommandText = "Select max(rctno)+1 FROM transid;"
            Try
                mRctNo = SQLcommand.ExecuteScalar
            Catch ex As Exception
                mRctNo = Rnd(3499999)
            End Try


            SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection

            Dim mSqlStr As String = "update " & mTable & " Set rctno = " & mRctNo &
                                    ",cashamt =" & mCashPaid &
                                    ",cashtot = " & mCashPaid & ",changetot = " & mChange &
                                    ",complete = 1,username='" & gUserId & "',paid=1  where saleid = " &
                                    SaleId & " and (rctno = 0 or rctno is Null)  and date = '" & mDate &
                                    "' and (complete = 0 or complete is null) and userid='" & gUserId & "';"
            SQLcommand.CommandText = mSqlStr
            SQLcommand.ExecuteNonQuery()

            SQLcommand = New MySqlCommand : SQLcommand.Connection = gSqlConnection
            SQLcommand.CommandText = "insert into transid (rctno,date,time) VALUES ('" &
                                        Val(mRctNo) & "','" & mDate & "','" & mTime & "');"
            SQLcommand.ExecuteNonQuery()

            ' -----------------------------------------------------------------
            Print_RCT(mCashPaid, mChange)

            MsgBox("Transaction Complete.", MsgBoxStyle.Information, "RexSof Pos.")
            mCancelPrintBill = False
            Me.Close()
        End If

    End Sub


    Public Function DrawLine(ByVal Objt As System.IO.StreamWriter, ByVal fs As Integer, Optional ByRef rcttxt As String = "")
        rcttxt = rcttxt & "\fs18 "
        rcttxt = rcttxt & "------------------------------------" & "\par"
        rcttxt = rcttxt & "\fs" & fs & " "

        Objt.WriteLine("\fs18 ")
        Objt.WriteLine("------------------------------------" & "\par")
        Objt.WriteLine("\fs" & fs & " ")
        Return 0
    End Function


    'to print with epos or any other receipt thermal printer text files does beter
    Public Sub Print_RCT(mCash As Double, mChange As Double)
        Try
            Dim mProductname As String
            Dim mQty As Double
            Dim mAmt As Double

            Dim mTotVat As String = 0

            Dim GBalDue As Double = 0
            Dim Change As Double = 0
            Dim mPaid As Double = 0

            Dim mRctDetails As String
            Dim PrintTime As String
            Dim mRctDate As String
            Dim CompTbl As New DataTable
            Dim SaleTbl As New DataTable
            Dim strLine As String

            Dim Adapter As New MySqlDataAdapter("select * from company;", gSqlConnection)

            CompTbl.Clear()
            Adapter.Fill(CompTbl)
            Adapter.Dispose()

            Adapter = New MySqlDataAdapter("select * from " & mTable & " where RctNo = " & mRctNo & " order by auto_number;", gSqlConnection)
            SaleTbl.Clear()
            Adapter.Fill(SaleTbl)
            Adapter.Dispose()

            If Dir(Application.StartupPath & "\Receipts", FileAttribute.Directory) = "" Then MkDir(Application.StartupPath & "\Receipts")
            Dim mIfShowAdd As Integer = 1
            Dim mifShowPin As Integer = 1
            Dim mifShowStreet As Integer = 1
            Dim mifShowTel As Integer = 1
            Dim CompName As String
            Dim CompAdd As String
            Dim CompTel As String
            Dim CompPin As String = ""
            Dim CompLoc As String = ""
            Dim mCompFs As Integer
            Dim mPrice As Double = 0
            Dim mTotalAmt As Double = 0

            Dim mRctTrailler1 As String = "Served By: "
            Dim mRctTrailler2 As String = "THANK YOU FOR SHOPPING WITH US"
            Dim mRctTrailler3 As String = "Goods Once Sold are not reaccepted"
            Change = mChange


            'input the company information
            Dim ii As Integer = 0
            If SaleTbl.Rows.Count > 0 Then

                If CompTbl.Rows.Count > 0 Then
                    CompName = CompTbl.Rows(0).Item("compname").ToString

                    CompAdd = CompTbl.Rows(0).Item("compadd").ToString
                    CompTel = CompTbl.Rows(0).Item("comptel").ToString
                    CompPin = CompTbl.Rows(0).Item("pinno").ToString
                    CompLoc = CompTbl.Rows(0).Item("location").ToString
                    mCompFs = 22
                Else
                    CompName = ""
                    CompAdd = ""
                    CompTel = ""
                End If

                If Change < 0 Then Change = Val(Change) * -1
                mTotVat = 0

                'Check if the file exists and delete the file if it exists
                If File.Exists(Application.StartupPath & "\Receipts\rct" & mRctNo & ".rtf") = True Then Kill(Application.StartupPath & "\Receipts\rct" & mRctNo & ".rtf")
                Dim mRct2 As String = mRctNo

                'create the text file
                Dim FILE_NAME As String = Application.StartupPath & "\Receipts\rct" & mRctNo & ".rtf"
                Dim ff As Integer = 0


                'start receipt data
                'INITIALIZE TEXT FILE
                Dim objWriter As New System.IO.StreamWriter(FILE_NAME, True)
                strLine = "{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fmodern\fprq1\fcharset0 Courier New;}" &
            "{\f1\fnil\fcharset0 Georgia;}{\f2\fnil\fcharset0 Microsoft Sans Serif;}{\f3\fnil\fcharset0 Arial Narrow;}}" &
            "{\*\generator Msftedit 5.41.15.1507;}\viewkind4\uc1\pard\qc\b\f0\fs30"
                objWriter.WriteLine(strLine)


                PrintTime = "TIME: " & Now.ToLongTimeString
                mRctDetails = "Receipt No: " & mRctNo.ToString
                mRctDate = "DATE: " & SaleTbl.Rows(0).Item("datedsc").ToString


                If mCompFs = 0 Then mCompFs = 22
                ' mCompFs = 30
                strLine = "\ql\b\f1\fs" & mCompFs & "\par " & CompName & "\par\fs18 "

                objWriter.WriteLine(strLine)
                'objWriter.WriteLine("\ql\b\f1\fs24 An affliate of Mona Limited\par ")
                strLine = "\ql\fs18 " & CompAdd & " \par "

                If mIfShowAdd = 1 Then objWriter.WriteLine(strLine)
                strLine = CompTel & " \f0\fs18\par "

                If mifShowTel = 1 Then objWriter.WriteLine(strLine)
                strLine = CompPin & " \f0\fs18\par "

                If mifShowPin = 1 Then objWriter.WriteLine(strLine)
                strLine = CompLoc & " \f0\fs18\par "

                If mifShowStreet = 1 Then objWriter.WriteLine(strLine)

                DrawLine(objWriter, 22)
                strLine = "\b\ul\ql\fs18 Cash Receipt \PAR\PAR\ul0\fs18 "

                objWriter.WriteLine(strLine)

                strLine = mRctDetails & "\par "

                objWriter.WriteLine(strLine)

                strLine = mRctDate & "\par "

                objWriter.WriteLine(strLine)

                strLine = PrintTime & "\par "

                objWriter.WriteLine(strLine)


                strLine = "\par\fs18 ITEM NAME" & "\par "


                objWriter.WriteLine(strLine)

                strLine = RSet("QUANTITY", 10) & RSet("PRICE", 12) & RSet("AMOUNT", 15) & "\par "
                'strLine =  "\par\fs16 " & LSet("ITEM NAME", 20) & RSet("QTY", 5) & RSet("PRICE", 7) & RSet("AMOUNT", 9) & "\par "

                objWriter.WriteLine(strLine)

                DrawLine(objWriter, 18)
                '@font size 18(rtf) width=38 chrts
                For ii = 0 To SaleTbl.Rows.Count - 1
                    mProductname = SaleTbl.Rows(ii).Item("Productname").ToString

                    mQty = Val(SaleTbl.Rows(ii).Item("qty").ToString)
                    mTotVat += Val(SaleTbl.Rows(ii).Item("taxamt").ToString)
                    mPrice = Val(SaleTbl.Rows(ii).Item("price").ToString)
                    mAmt = Val(SaleTbl.Rows(ii).Item("amount").ToString)
                    mTotalAmt += mAmt

                    strLine = LSet(mProductname, 35) & " \par "
                    objWriter.WriteLine(strLine)
                    strLine = RSet(mQty.ToString, 10) & " " & RSet(mPrice.ToString, 11) & " " & RSet(mAmt.ToString, 12) & "\par "
                    objWriter.WriteLine(strLine)

                    Application.DoEvents()
                Next

                DrawLine(objWriter, 22)
                strLine = "TOTAL:" & RSet(FormatNumber(Val(mTotalAmt), 2, TriState.True, TriState.True, TriState.True), 19) & "\par "
                objWriter.WriteLine(strLine)

                strLine = "Cash Paid:" & RSet(FormatNumber(Val(mCash), 2, TriState.True, TriState.True, TriState.True), 20) & "\par "
                objWriter.WriteLine(strLine)
                strLine = "CHANGE:" & RSet(FormatNumber(Val(Change), 2, TriState.True, TriState.True, TriState.True), 22) & "\par "
                objWriter.WriteLine(strLine)
                strLine = " \ql\f0\fs16 "
                objWriter.WriteLine(strLine)
                strLine = "\par TAX AMOUNT:: " & RSet(FormatNumber(Val(mTotVat), 2, TriState.True, TriState.True, TriState.True), 19) & "\par"
                objWriter.WriteLine(strLine)
                DrawLine(objWriter, 18)
                strLine = "\fs20 " & mRctTrailler1 & " " & gUserName & "\par\par "
                objWriter.WriteLine(strLine)

                strLine = "\par\qc\fs20 " & mRctTrailler2
                objWriter.WriteLine(strLine)
                strLine = "\par\fs20 " & mRctTrailler3 & "\par"
                objWriter.WriteLine(strLine)
                strLine = "\par\f1\ql\fs16 GECHEMBA MOCHOGE ADELIDE \par"
                objWriter.WriteLine(strLine)
                strLine = "\f2\fs20\b\ql "
                objWriter.WriteLine(strLine)
                objWriter.Close()

                Dim path As String = FILE_NAME
                Dim p As New Process
                Dim info As New ProcessStartInfo
                info.FileName = path
                info.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                info.CreateNoWindow = True
                info.Verb = "print"
                p.StartInfo = info
                p.Start()
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Exclamation, "A Problem Has Occured")
        End Try
    End Sub

    Private Sub Cancel_Button_Click(sender As Object, e As EventArgs) Handles Cancel_Button.Click
        Call frmPrintReciptCurrentSale_KeyDown(OK_Button, New KeyEventArgs(Keys.Escape))
    End Sub

    Private Sub frmPrintReciptCurrentSale_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtTotal.Text = FormatNumber(mtotal, 2)

        txtcashPaid.Text = mtotal
        mCancelPrintBill = False
    End Sub
End Class